import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { MongoClient, Db } from 'mongodb';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// ==========================================
// SEED PRODUCTS (Realistic Dress Catalog)
// ==========================================
const INITIAL_PRODUCTS = [
  {
    id: "sn-prod-001",
    name: "Embroidered Anarkali Kurti with Dupatta",
    slug: "embroidered-anarkali-kurti-dupatta",
    category: "Kurtis",
    brand: "Gulabi Vastra",
    originalPrice: 1999,
    sellingPrice: 849,
    discountPercent: 57,
    images: [
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Blush Rose", hex: "#f472b6" },
      { name: "Lavender Lilac", hex: "#c084fc" },
      { name: "Classic Off-White", hex: "#faf5ff" }
    ],
    fabric: "Pure Rayon Viscose with Zari Threadwork",
    fit: "Flared Anarkali Silhouette",
    pattern: "Floral Neckline Embroidery with Gota Patti Border",
    careInstructions: "First wash dry clean recommended, followed by gentle hand wash in cold water.",
    stock: 18,
    rating: 4.6,
    reviewCount: 342,
    isNewArrival: true,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: false,
    isPublished: true,
    description: "Graceful festive Anarkali kurti crafted from breathable rayon with intricate floral neck embroidery and delicate silver gota detailing along the flared hemline. Perfect for festivals, family functions, and office celebrations.",
    reviews: [
      {
        id: "rev-01",
        userName: "Ananya Sharma",
        rating: 5,
        date: "2026-10-14",
        title: "Loved the quality and fit!",
        comment: "The blush pink shade is exactly as pictured. Fabric is soft, non-sheer, and the flare is gorgeous.",
        verifiedPurchase: true,
        userCity: "Jaipur"
      },
      {
        id: "rev-02",
        userName: "Pooja Verma",
        rating: 4,
        date: "2026-09-28",
        title: "Value for money kurti",
        comment: "Great quality for the price. Dupatta fabric is lightweight chiffon. Delivered in 3 days.",
        verifiedPurchase: true,
        userCity: "Bengaluru"
      }
    ],
    createdAt: "2026-10-01T10:00:00.000Z"
  },
  {
    id: "sn-prod-002",
    name: "Lavender Floral Organza Festive Saree",
    slug: "lavender-floral-organza-festive-saree",
    category: "Sarees",
    brand: "Rang Sutra",
    originalPrice: 2499,
    sellingPrice: 1199,
    discountPercent: 52,
    images: [
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "Lilac Bloom", hex: "#d8b4fe" },
      { name: "Powder Pink", hex: "#fbcfe8" }
    ],
    fabric: "Premium Lightweight Digital Printed Organza",
    fit: "Free Size (5.5m Saree + 0.8m Unstitched Blouse Piece)",
    pattern: "Hand-painted Watercolor Floral with Scalloped Border",
    careInstructions: "Dry clean only to preserve delicate metallic sheen and scalloped edges.",
    stock: 12,
    rating: 4.8,
    reviewCount: 215,
    isNewArrival: true,
    isTrending: true,
    isBestSeller: false,
    isSpecialOffer: false,
    isPublished: true,
    description: "Ethereal translucent organza saree with romantic lilac blooming prints and delicate scalloped embroidery. Lightweight, easy to drape, and pairs wonderfully with pearl jewelry.",
    reviews: [
      {
        id: "rev-03",
        userName: "Sneha Mukherjee",
        rating: 5,
        date: "2026-10-18",
        title: "Stunning festive look!",
        comment: "Received so many compliments at my friend's engagement party. The lilac drape is feather-light.",
        verifiedPurchase: true,
        userCity: "Kolkata"
      }
    ],
    createdAt: "2026-10-05T12:00:00.000Z"
  },
  {
    id: "sn-prod-003",
    name: "Tiered Pastel Puff-Sleeve Midi Dress",
    slug: "tiered-pastel-puff-sleeve-midi-dress",
    category: "Dresses",
    brand: "Aura Chic",
    originalPrice: 1699,
    sellingPrice: 699,
    discountPercent: 58,
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Candy Pink", hex: "#f472b6" },
      { name: "Mauve Mist", hex: "#e9d5ff" },
      { name: "Crisp Ivory", hex: "#ffffff" }
    ],
    fabric: "100% Breathable Cotton Slub with Cotton Lining",
    fit: "A-Line Relaxed Tiered Fit with Smocked Back",
    pattern: "Subtle Micro Floral Dobby Weave",
    careInstructions: "Machine wash cold with like colors. Do not bleach. Warm iron inside out.",
    stock: 25,
    rating: 4.5,
    reviewCount: 489,
    isNewArrival: false,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: true,
    isPublished: true,
    description: "Breezy romantic midi dress featuring feminine elasticated puff sleeves, tiered ruffle skirt, and a stretchy smocked back for the most flattering fit. Ideal for brunch, vacations, and casual outings.",
    reviews: [
      {
        id: "rev-04",
        userName: "Ritu Nair",
        rating: 5,
        date: "2026-10-20",
        title: "Super comfy and pretty",
        comment: "The smocked back makes it fit like a dream! Fabric is 100% cotton so it doesn't feel hot at all.",
        verifiedPurchase: true,
        userCity: "Kochi"
      }
    ],
    createdAt: "2026-09-20T08:00:00.000Z"
  },
  {
    id: "sn-prod-004",
    name: "Schiffli Peplum Top with Sweetheart Neck",
    slug: "schiffli-peplum-top-sweetheart-neck",
    category: "Tops",
    brand: "StyleNest Studio",
    originalPrice: 1299,
    sellingPrice: 499,
    discountPercent: 61,
    images: [
      "https://images.unsplash.com/photo-1589310243389-96a5483213a8?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Soft Lavender", hex: "#c084fc" },
      { name: "Cotton Pink", hex: "#fbcfe8" },
      { name: "Pure White", hex: "#f8fafc" }
    ],
    fabric: "100% Pure Schiffli Cotton Embroidery",
    fit: "Peplum Flared Waist with Front Decorative Buttons",
    pattern: "Geometric Cutwork Eyelet Embroidery",
    careInstructions: "Gentle cycle machine wash in laundry bag or hand wash. Shade dry.",
    stock: 30,
    rating: 4.4,
    reviewCount: 164,
    isNewArrival: true,
    isTrending: false,
    isBestSeller: false,
    isSpecialOffer: true,
    isPublished: true,
    description: "Charming eyelet cutwork peplum top featuring a flattering sweetheart neckline, lightly puffed sleeves, and a breezy cinched waist. Pairs effortlessly with high-waist jeans or skirts.",
    reviews: [
      {
        id: "rev-05",
        userName: "Kavya Patel",
        rating: 4,
        date: "2026-10-12",
        title: "Very chic top",
        comment: "Looks very premium in white and lavender. Material has good lining so no see-through issues.",
        verifiedPurchase: true,
        userCity: "Ahmedabad"
      }
    ],
    createdAt: "2026-10-10T14:30:00.000Z"
  },
  {
    id: "sn-prod-005",
    name: "High-Rise Wide-Leg Cotton Stretch Jeans",
    slug: "high-rise-wide-leg-cotton-stretch-jeans",
    category: "Jeans",
    brand: "DenimCraze",
    originalPrice: 1999,
    sellingPrice: 899,
    discountPercent: 55,
    images: [
      "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Ice Blue", hex: "#bae6fd" },
      { name: "Pastel Lilac Tint", hex: "#e9d5ff" },
      { name: "Midnight Indigo", hex: "#1e1b4b" }
    ],
    fabric: "98% Cotton, 2% Elastane Flex Denim",
    fit: "Relaxed High-Rise Straight Wide Leg",
    pattern: "Solid Clean Wash with Contrast Stitching",
    careInstructions: "Machine wash cold inside out. Wash dark colors separately.",
    stock: 15,
    rating: 4.7,
    reviewCount: 380,
    isNewArrival: false,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: false,
    isPublished: true,
    description: "Ultra-comfortable high-waisted wide-leg jeans with 2-way stretch that moves with you all day. Designed to elongate the legs while maintaining all-day softness.",
    reviews: [
      {
        id: "rev-06",
        userName: "Meera Sen",
        rating: 5,
        date: "2026-10-08",
        title: "Best fitting wide leg jeans!",
        comment: "Fit around the waist is snug without digging in. Super soft denim.",
        verifiedPurchase: true,
        userCity: "Pune"
      }
    ],
    createdAt: "2026-09-15T11:00:00.000Z"
  },
  {
    id: "sn-prod-006",
    name: "Ultra-Soft Bamboo Cotton Ankle Leggings (Pack of 2)",
    slug: "ultra-soft-bamboo-cotton-ankle-leggings",
    category: "Leggings",
    brand: "ComfyFit",
    originalPrice: 999,
    sellingPrice: 399,
    discountPercent: 60,
    images: [
      "https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Dusty Rose & Wine", hex: "#be185d" },
      { name: "Lilac & Charcoal", hex: "#a855f7" },
      { name: "Pure Black & Off-White", hex: "#0f172a" }
    ],
    fabric: "95% Organic Combed Cotton, 5% Lycra Spandex",
    fit: "Ankle-Length 4-Way Stretch High Waistband",
    pattern: "Solid Chroma Fast Dye (Non-Fading)",
    careInstructions: "Machine wash normal. Color will not bleed.",
    stock: 45,
    rating: 4.6,
    reviewCount: 890,
    isNewArrival: false,
    isTrending: false,
    isBestSeller: true,
    isSpecialOffer: true,
    isPublished: true,
    description: "Buttery soft 4-way stretch ankle leggings crafted from premium combed organic cotton. Features a wide anti-roll waistband that stays put without pinching.",
    reviews: [
      {
        id: "rev-07",
        userName: "Divya Krishnan",
        rating: 5,
        date: "2026-10-19",
        title: "Cannot beat this comfort",
        comment: "So soft and 100% non-see-through even when bending. Definitely buying more packs.",
        verifiedPurchase: true,
        userCity: "Chennai"
      }
    ],
    createdAt: "2026-09-01T09:00:00.000Z"
  },
  {
    id: "sn-prod-007",
    name: "Printed Satin Notch-Collar Pyjama Sleepwear Set",
    slug: "printed-satin-notch-collar-pyjama-sleepwear-set",
    category: "Nightwear",
    brand: "Luxe Dream",
    originalPrice: 1899,
    sellingPrice: 799,
    discountPercent: 58,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Pastel Lavender Dots", hex: "#c084fc" },
      { name: "Blush Silk Pink", hex: "#f472b6" },
      { name: "Midnight Plum", hex: "#581c87" }
    ],
    fabric: "Silky Smooth Poly-Satin with Contrast Piping",
    fit: "Relaxed Fit Shirt & Elasticated Drawstring Trousers",
    pattern: "Delicate Polka & Floral Motif",
    careInstructions: "Gentle machine wash or hand wash in cold water with mild detergent.",
    stock: 22,
    rating: 4.7,
    reviewCount: 310,
    isNewArrival: true,
    isTrending: true,
    isBestSeller: false,
    isSpecialOffer: false,
    isPublished: true,
    description: "Pamper yourself with this ultra-luxurious silky satin sleepwear set. Designed with a timeless notch collar, mother-of-pearl style buttons, and a relaxed pyjama with practical deep side pockets.",
    reviews: [
      {
        id: "rev-08",
        userName: "Tanya Bansal",
        rating: 5,
        date: "2026-10-21",
        title: "Looks and feels like high-end boutique wear",
        comment: "Fabric feels like pure silk on skin. Satin piping gives a very royal aesthetic.",
        verifiedPurchase: true,
        userCity: "Delhi NCR"
      }
    ],
    createdAt: "2026-10-12T16:00:00.000Z"
  },
  {
    id: "sn-prod-008",
    name: "Heavy Zari Embroidered Silk Lehenga Choli",
    slug: "heavy-zari-embroidered-silk-lehenga-choli",
    category: "Traditional Wear",
    brand: "Rajwada Couture",
    originalPrice: 4999,
    sellingPrice: 2299,
    discountPercent: 54,
    images: [
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Rose Gold Pink", hex: "#fb7185" },
      { name: "Royal Lavender", hex: "#9333ea" },
      { name: "Ivory Pearl", hex: "#f8fafc" }
    ],
    fabric: "Semi-Stitched Art Silk with Heavy Can-Can Net Lining",
    fit: "Flared 3.5m Ghagra with Padded Blouse & Net Dupatta",
    pattern: "Heavy Floral Resham Thread & Dori Zari Work with Sequins",
    careInstructions: "Professional Dry Clean Only.",
    stock: 8,
    rating: 4.9,
    reviewCount: 178,
    isNewArrival: true,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: false,
    isPublished: true,
    description: "Opulent wedding and sangeet lehenga choli featuring intricate dori threadwork, sparkling micro sequins, and an expansive 3.5-meter flare with built-in double can-can. Complete with matching blouse and scalloped net dupatta.",
    reviews: [
      {
        id: "rev-09",
        userName: "Simran Kaur",
        rating: 5,
        date: "2026-10-15",
        title: "Worth twice the price!",
        comment: "Can-can provides tremendous flare just like designer bridal lehengas. Zari work is neat and heavy.",
        verifiedPurchase: true,
        userCity: "Chandigarh"
      }
    ],
    createdAt: "2026-10-08T18:00:00.000Z"
  },
  {
    id: "sn-prod-009",
    name: "Straight Chikankari Embroidered Cotton Kurti",
    slug: "straight-chikankari-embroidered-cotton-kurti",
    category: "Kurtis",
    brand: "Gulabi Vastra",
    originalPrice: 1499,
    sellingPrice: 599,
    discountPercent: 60,
    images: [
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Powder Pink", hex: "#fbcfe8" },
      { name: "Light Lilac", hex: "#e9d5ff" },
      { name: "Snow White", hex: "#ffffff" }
    ],
    fabric: "100% Breathable Mulmul Cotton",
    fit: "Straight Cut with Side Slits",
    pattern: "Authentic Lucknowi Shadow & Bakhiya Handwork",
    careInstructions: "Hand wash gently in cold water with mild detergent.",
    stock: 20,
    rating: 4.7,
    reviewCount: 420,
    isNewArrival: false,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: true,
    isPublished: true,
    description: "Authentic Lucknowi Chikankari embroidered kurti in lightweight breathable mulmul cotton. Featuring delicate bakhiya and phanda work that looks effortlessly stylish with palazzos, denims, or leggings.",
    reviews: [
      {
        id: "rev-10",
        userName: "Priya Nair",
        rating: 5,
        date: "2026-10-11",
        title: "Pure cotton perfection",
        comment: "So soft on skin! Hand embroidery is very neat. Perfect for daily office wear.",
        verifiedPurchase: true,
        userCity: "Hyderabad"
      }
    ],
    createdAt: "2026-09-18T10:00:00.000Z"
  },
  {
    id: "sn-prod-010",
    name: "Floral Wrap Summer Sundress with Tie Belt",
    slug: "floral-wrap-summer-sundress-tie-belt",
    category: "Dresses",
    brand: "Aura Chic",
    originalPrice: 1799,
    sellingPrice: 749,
    discountPercent: 58,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Lavender Meadow", hex: "#c084fc" },
      { name: "Petal Rose", hex: "#f472b6" }
    ],
    fabric: "Soft Flowy Georgette with Butter-Crepe Lining",
    fit: "Adjustable Wrap Front with V-Neckline",
    pattern: "Micro Pastel Floral Daisy Print",
    careInstructions: "Machine wash cold. Line dry in shade.",
    stock: 14,
    rating: 4.6,
    reviewCount: 198,
    isNewArrival: true,
    isTrending: true,
    isBestSeller: false,
    isSpecialOffer: false,
    isPublished: true,
    description: "Flirty and flattering floral wrap sundress with a customizable waist tie, ruffled flutter sleeves, and fluid draped hemline. Perfect for weekend getaways, dates, and garden parties.",
    reviews: [
      {
        id: "rev-11",
        userName: "Ananya Iyer",
        rating: 5,
        date: "2026-10-23",
        title: "Flattering cut!",
        comment: "The wrap allows you to adjust the fit exactly how you want. Very feminine and pretty.",
        verifiedPurchase: true,
        userCity: "Mumbai"
      }
    ],
    createdAt: "2026-10-17T09:00:00.000Z"
  },
  {
    id: "sn-prod-011",
    name: "Kanjivaram Soft Silk Saree with Rich Pallu",
    slug: "kanjivaram-soft-silk-saree-rich-pallu",
    category: "Sarees",
    brand: "Rang Sutra",
    originalPrice: 3499,
    sellingPrice: 1499,
    discountPercent: 57,
    images: [
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "Magenta Pink & Gold", hex: "#db2777" },
      { name: "Lilac Violet & Silver", hex: "#9333ea" }
    ],
    fabric: "High-Grade Soft Litchi Silk Blend",
    fit: "Traditional 6-Yard Saree with Contrast Blouse",
    pattern: "Intricate Peacock & Floral Zari Weaving",
    careInstructions: "Dry clean recommended for long-lasting zari luster.",
    stock: 10,
    rating: 4.8,
    reviewCount: 312,
    isNewArrival: false,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: false,
    isPublished: true,
    description: "Royal Kanjivaram inspired soft silk saree adorned with rich woven golden zari motifs on the pallu and contrasting borders. Lightweight and easy to pleat without stiffness.",
    reviews: [
      {
        id: "rev-12",
        userName: "Deepa R.",
        rating: 5,
        date: "2026-09-30",
        title: "Pleats so smoothly",
        comment: "Unlike stiff silk sarees, this soft silk saree drapes so effortlessly. The gold zari has a subtle, rich glow.",
        verifiedPurchase: true,
        userCity: "Coimbatore"
      }
    ],
    createdAt: "2026-09-22T11:00:00.000Z"
  },
  {
    id: "sn-prod-012",
    name: "Ribbed Knit Square-Neck Fitted Top",
    slug: "ribbed-knit-square-neck-fitted-top",
    category: "Tops",
    brand: "StyleNest Studio",
    originalPrice: 999,
    sellingPrice: 349,
    discountPercent: 65,
    images: [
      "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1589310243389-96a5483213a8?auto=format&fit=crop&w=800&q=80"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Baby Pink", hex: "#f472b6" },
      { name: "Lilac Haze", hex: "#c084fc" },
      { name: "Oatmeal Cream", hex: "#f5f3ff" }
    ],
    fabric: "92% Viscose, 8% Elastane Fine Ribbed Knit",
    fit: "Body-Hugging Slim Fit with Elegant Square Neckline",
    pattern: "Solid Vertical Fine Rib",
    careInstructions: "Machine wash cold inside laundry bag. Flat dry.",
    stock: 35,
    rating: 4.5,
    reviewCount: 520,
    isNewArrival: false,
    isTrending: true,
    isBestSeller: true,
    isSpecialOffer: true,
    isPublished: true,
    description: "An everyday wardrobe staple featuring a clean square neckline that frames the collarbone beautifully. High-stretch ribbed knit that retains its shape after countless washes.",
    reviews: [
      {
        id: "rev-13",
        userName: "Shreya Joshi",
        rating: 5,
        date: "2026-10-16",
        title: "Such a flattering neck design",
        comment: "The square neck looks so modern. Thick enough fabric that you don't need to worry about innerwear lines.",
        verifiedPurchase: true,
        userCity: "Indore"
      }
    ],
    createdAt: "2026-09-10T15:00:00.000Z"
  }
];

// In-Memory dynamic store that replicates MongoDB collections
let memoryProducts: any[] = JSON.parse(JSON.stringify(INITIAL_PRODUCTS));
let memoryOrders: any[] = [];
let memoryUsers: any[] = [
  {
    id: "usr-demo-01",
    name: "Pooja Kaliappan",
    email: "poojakaliappan490@gmail.com",
    phone: "9876543210",
    address: {
      fullName: "Pooja Kaliappan",
      phone: "9876543210",
      street: "Flat 402, Lotus Orchid Apartments, MG Road",
      city: "Bengaluru",
      state: "Karnataka",
      pincode: "560001"
    },
    wishlist: ["sn-prod-001", "sn-prod-003"],
    createdAt: "2026-09-01T00:00:00.000Z"
  }
];

// MongoDB Atlas connection state
let mongoClient: MongoClient | null = null;
let mongoDb: Db | null = null;
let isMongoConnected = false;
let mongoConnectionError: string | null = null;

async function initMongoDB() {
  const mongoUri = process.env.MONGODB_URI;
  if (!mongoUri || mongoUri.trim() === '') {
    console.log('[StyleNest Server] MONGODB_URI not provided in .env. Running on fast dynamic local store.');
    return;
  }

  try {
    console.log('[StyleNest Server] Connecting to MongoDB Atlas...');
    mongoClient = new MongoClient(mongoUri);
    await mongoClient.connect();
    mongoDb = mongoClient.db('stylenest');
    isMongoConnected = true;
    mongoConnectionError = null;
    console.log('[StyleNest Server] Successfully connected to MongoDB Atlas!');

    // Check if products collection exists or is empty; seed if needed
    const productsColl = mongoDb.collection('products');
    const count = await productsColl.countDocuments();
    if (count === 0) {
      console.log('[StyleNest Server] Seeding initial dress catalog into MongoDB Atlas...');
      await productsColl.insertMany(INITIAL_PRODUCTS);
      console.log('[StyleNest Server] Seeded', INITIAL_PRODUCTS.length, 'products into MongoDB Atlas.');
    }
  } catch (err: any) {
    isMongoConnected = false;
    mongoConnectionError = err?.message || 'Failed to connect to MongoDB Atlas';
    console.error('[StyleNest Server] MongoDB connection error:', mongoConnectionError);
  }
}

initMongoDB();

// ==========================================
// REST API ENDPOINTS
// ==========================================

// 1. Health & Database Status Check
app.get('/api/status', async (_req, res) => {
  let productCount = memoryProducts.length;
  let ordersCount = memoryOrders.length;

  if (isMongoConnected && mongoDb) {
    try {
      productCount = await mongoDb.collection('products').countDocuments({ isPublished: true });
      ordersCount = await mongoDb.collection('orders').countDocuments();
    } catch {
      // fallback to memory count
    }
  }

  res.json({
    connected: isMongoConnected,
    database: isMongoConnected ? 'mongodb' : 'memory-store',
    productCount,
    ordersCount,
    mongoUriConfigured: Boolean(process.env.MONGODB_URI && process.env.MONGODB_URI.trim() !== ''),
    errorMessage: mongoConnectionError,
    message: isMongoConnected 
      ? 'Connected to live MongoDB Atlas database. Product and order updates are permanently stored.'
      : 'Running with initialized local high-speed store. To connect live MongoDB Atlas, add your connection string to MONGODB_URI in .env.'
  });
});

// 2. Categories List with Product Counts
app.get('/api/categories', async (_req, res) => {
  const categoriesList = [
    { name: 'Kurtis', slug: 'kurtis', icon: 'Sparkles', description: 'Chikankari, Anarkali & Straight Kurtas' },
    { name: 'Sarees', slug: 'sarees', icon: 'Palette', description: 'Organza, Soft Silk, Georgette Drapes' },
    { name: 'Tops', slug: 'tops', icon: 'Shirt', description: 'Peplum, Schiffli & Ribbed Tops' },
    { name: 'Dresses', slug: 'dresses', icon: 'Heart', description: 'Tiered Midis, Wrap Dresses & Gowns' },
    { name: 'Jeans', slug: 'jeans', icon: 'Scissors', description: 'Wide-Leg, Flare & Mom-Fit Denims' },
    { name: 'Leggings', slug: 'leggings', icon: 'Layers', description: 'Ankle-Length 4-Way Stretch Leggings' },
    { name: 'Nightwear', slug: 'nightwear', icon: 'Moon', description: 'Satin Pyjama Sets & Comfy Lounge' },
    { name: 'Traditional Wear', slug: 'traditional-wear', icon: 'Crown', description: 'Lehengas, Shararas & Wedding Sets' }
  ];

  let products = memoryProducts;
  if (isMongoConnected && mongoDb) {
    try {
      products = await mongoDb.collection('products').find({ isPublished: true }).toArray() as any;
    } catch {}
  }

  const result = categoriesList.map(cat => ({
    ...cat,
    count: products.filter((p: any) => p.category === cat.name && p.isPublished).length
  }));

  res.json({ categories: result });
});

// 3. Products List with Full Filtering, Search & Sorting
app.get('/api/products', async (req, res) => {
  try {
    const {
      search,
      category,
      minPrice,
      maxPrice,
      size,
      color,
      rating,
      inStock,
      sort,
      tag
    } = req.query;

    let items: any[] = [];
    if (isMongoConnected && mongoDb) {
      const query: any = { isPublished: true };
      if (category && category !== 'All') {
        query.category = category;
      }
      if (tag === 'new-arrivals') query.isNewArrival = true;
      if (tag === 'trending') query.isTrending = true;
      if (tag === 'best-sellers') query.isBestSeller = true;
      if (tag === 'special-offers') query.isSpecialOffer = true;

      items = await mongoDb.collection('products').find(query).toArray();
    } else {
      items = memoryProducts.filter((p: any) => p.isPublished);
      if (category && category !== 'All') {
        items = items.filter((p: any) => p.category.toLowerCase() === String(category).toLowerCase());
      }
      if (tag === 'new-arrivals') items = items.filter((p: any) => p.isNewArrival);
      if (tag === 'trending') items = items.filter((p: any) => p.isTrending);
      if (tag === 'best-sellers') items = items.filter((p: any) => p.isBestSeller);
      if (tag === 'special-offers') items = items.filter((p: any) => p.isSpecialOffer);
    }

    // Apply In-Memory/Dynamic Filters for high responsiveness
    if (search && String(search).trim() !== '') {
      const q = String(search).toLowerCase().trim();
      items = items.filter((p: any) => 
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.fabric.toLowerCase().includes(q) ||
        p.pattern.toLowerCase().includes(q)
      );
    }

    if (minPrice) {
      items = items.filter((p: any) => p.sellingPrice >= Number(minPrice));
    }
    if (maxPrice) {
      items = items.filter((p: any) => p.sellingPrice <= Number(maxPrice));
    }

    if (size && size !== 'All') {
      items = items.filter((p: any) => Array.isArray(p.sizes) && p.sizes.includes(String(size)));
    }

    if (color && color !== 'All') {
      items = items.filter((p: any) => 
        Array.isArray(p.colors) && 
        p.colors.some((c: any) => c.name.toLowerCase().includes(String(color).toLowerCase()))
      );
    }

    if (rating) {
      items = items.filter((p: any) => p.rating >= Number(rating));
    }

    if (inStock === 'true') {
      items = items.filter((p: any) => p.stock > 0);
    }

    // Sorting
    if (sort === 'price-low') {
      items.sort((a, b) => a.sellingPrice - b.sellingPrice);
    } else if (sort === 'price-high') {
      items.sort((a, b) => b.sellingPrice - a.sellingPrice);
    } else if (sort === 'newest') {
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } else if (sort === 'discount') {
      items.sort((a, b) => b.discountPercent - a.discountPercent);
    } else {
      // Default: popularity / rating
      items.sort((a, b) => (b.rating * b.reviewCount) - (a.rating * a.reviewCount));
    }

    res.json({
      products: items,
      total: items.length,
      source: isMongoConnected ? 'mongodb' : 'memory-store'
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch products' });
  }
});

// 4. Single Product by ID or Slug
app.get('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  let product: any = null;

  if (isMongoConnected && mongoDb) {
    try {
      product = await mongoDb.collection('products').findOne({
        $or: [{ id }, { slug: id }]
      });
    } catch {}
  }

  if (!product) {
    product = memoryProducts.find((p: any) => p.id === id || p.slug === id);
  }

  if (!product) {
    res.status(404).json({ error: 'Product not found' });
    return;
  }

  // Find similar products in same category
  let similar: any[] = [];
  if (isMongoConnected && mongoDb) {
    try {
      similar = await mongoDb.collection('products').find({
        category: product.category,
        id: { $ne: product.id },
        isPublished: true
      }).limit(4).toArray();
    } catch {}
  }
  if (!similar.length) {
    similar = memoryProducts
      .filter((p: any) => p.category === product.category && p.id !== product.id && p.isPublished)
      .slice(0, 4);
  }

  res.json({ product, similar });
});

// 5. Auth: Register
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) {
    res.status(400).json({ error: 'Name, email, and password are required' });
    return;
  }

  const existingEmail = memoryUsers.some(u => u.email.toLowerCase() === email.toLowerCase());
  if (existingEmail) {
    res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
    return;
  }

  const newUser = {
    id: `usr-${Date.now()}`,
    name: name.trim(),
    email: email.toLowerCase().trim(),
    phone: phone || '',
    wishlist: [],
    createdAt: new Date().toISOString()
  };

  memoryUsers.push(newUser);

  if (isMongoConnected && mongoDb) {
    try {
      await mongoDb.collection('users').insertOne(newUser);
    } catch (e) {
      console.error('Mongo user insert error:', e);
    }
  }

  res.status(201).json({
    message: 'Account created successfully',
    user: newUser
  });
});

// 6. Auth: Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required' });
    return;
  }

  let user = memoryUsers.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
  if (isMongoConnected && mongoDb && !user) {
    try {
      user = await mongoDb.collection('users').findOne({ email: email.toLowerCase().trim() }) as any;
    } catch {}
  }

  if (!user) {
    // For seamless experience, if user isn't found in memory, create account automatically on login
    const autoUser = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email: email.toLowerCase().trim(),
      phone: '9876543210',
      wishlist: [],
      createdAt: new Date().toISOString()
    };
    memoryUsers.push(autoUser);
    res.json({ message: 'Welcome to StyleNest!', user: autoUser });
    return;
  }

  res.json({
    message: 'Login successful',
    user
  });
});

// 7. Auth: Update Profile
app.put('/api/auth/profile', (req, res) => {
  const { userId, name, phone, address } = req.body;
  const user = memoryUsers.find(u => u.id === userId);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  if (name) user.name = name;
  if (phone) user.phone = phone;
  if (address) user.address = address;

  if (isMongoConnected && mongoDb) {
    mongoDb.collection('users').updateOne(
      { id: userId },
      { $set: { name: user.name, phone: user.phone, address: user.address } }
    ).catch(console.error);
  }

  res.json({ message: 'Profile updated', user });
});

// 8. Orders: Place Order with Server-Side Validation
app.post('/api/orders', async (req, res) => {
  try {
    const { items, shippingAddress, paymentMethod, userId } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Order must contain at least one item' });
      return;
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.phone || !shippingAddress.street || !shippingAddress.pincode) {
      res.status(400).json({ error: 'Complete delivery address including PIN code is required' });
      return;
    }

    // Server-Side Stock & Price Validation
    let calculatedSubtotal = 0;
    let validatedItems: any[] = [];

    for (const item of items) {
      let product = memoryProducts.find((p: any) => p.id === item.productId);
      if (isMongoConnected && mongoDb && !product) {
        product = await mongoDb.collection('products').findOne({ id: item.productId }) as any;
      }

      if (!product) {
        res.status(400).json({ error: `Product ${item.name || item.productId} no longer exists` });
        return;
      }

      if (product.stock < item.quantity) {
        res.status(400).json({
          error: `Insufficient stock for "${product.name}". Only ${product.stock} available.`
        });
        return;
      }

      const itemTotal = product.sellingPrice * item.quantity;
      calculatedSubtotal += itemTotal;

      validatedItems.push({
        productId: product.id,
        name: product.name,
        image: product.images[0],
        size: item.size,
        color: item.color,
        price: product.sellingPrice,
        quantity: item.quantity
      });

      // Reduce product stock in store
      product.stock -= item.quantity;
      if (isMongoConnected && mongoDb) {
        mongoDb.collection('products').updateOne(
          { id: product.id },
          { $set: { stock: product.stock } }
        ).catch(console.error);
      }
    }

    // Delivery charge calculation: Free delivery on ₹499+
    const deliveryCharge = calculatedSubtotal >= 499 ? 0 : 49;
    const discount = calculatedSubtotal > 1500 ? Math.round(calculatedSubtotal * 0.1) : 0;
    const finalTotal = calculatedSubtotal - discount + deliveryCharge;

    const orderNumber = `SN-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;
    const now = new Date();
    const estDelivery = new Date(now.getTime() + 4 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });

    const newOrder = {
      id: `ord-${Date.now()}`,
      orderNumber,
      userId: userId || 'usr-guest',
      date: now.toISOString(),
      items: validatedItems,
      subtotal: calculatedSubtotal,
      discount,
      deliveryCharge,
      totalAmount: finalTotal,
      shippingAddress,
      paymentMethod: paymentMethod || 'COD',
      paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Paid',
      status: 'Placed',
      estimatedDelivery: estDelivery,
      timeline: [
        {
          status: 'Placed',
          timestamp: now.toISOString(),
          description: 'Order placed successfully and received by StyleNest seller.',
          completed: true
        },
        {
          status: 'Confirmed',
          timestamp: '',
          description: 'Seller is packing your garments.',
          completed: false
        },
        {
          status: 'Shipped',
          timestamp: '',
          description: 'Handed over to delivery courier.',
          completed: false
        },
        {
          status: 'Delivered',
          timestamp: '',
          description: 'Delivered to your doorstep.',
          completed: false
        }
      ]
    };

    memoryOrders.unshift(newOrder);

    if (isMongoConnected && mongoDb) {
      try {
        await mongoDb.collection('orders').insertOne(newOrder);
      } catch (e) {
        console.error('Mongo order insert error:', e);
      }
    }

    res.status(201).json({
      message: 'Order placed successfully',
      order: newOrder
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to place order' });
  }
});

// 9. Orders: List Orders for User
app.get('/api/orders', async (req, res) => {
  const { userId } = req.query;
  let orders = memoryOrders;

  if (isMongoConnected && mongoDb) {
    try {
      const query = userId ? { userId } : {};
      orders = await mongoDb.collection('orders').find(query).sort({ date: -1 }).toArray() as any;
    } catch {}
  } else if (userId) {
    orders = memoryOrders.filter(o => o.userId === userId);
  }

  res.json({ orders });
});

// 10. Orders: Cancel Order (Only if Placed or Confirmed)
app.patch('/api/orders/:id/cancel', async (req, res) => {
  const { id } = req.params;
  const { reason } = req.body;

  let order = memoryOrders.find(o => o.id === id || o.orderNumber === id);
  if (isMongoConnected && mongoDb && !order) {
    try {
      order = await mongoDb.collection('orders').findOne({
        $or: [{ id }, { orderNumber: id }]
      }) as any;
    } catch {}
  }

  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }

  if (order.status !== 'Placed' && order.status !== 'Confirmed') {
    res.status(400).json({
      error: `Cannot cancel order in "${order.status}" status. Orders can only be cancelled prior to dispatch.`
    });
    return;
  }

  order.status = 'Cancelled';
  order.timeline.push({
    status: 'Cancelled',
    timestamp: new Date().toISOString(),
    description: reason || 'Customer requested order cancellation',
    completed: true
  });

  // Restore inventory
  for (const item of order.items) {
    const prod = memoryProducts.find((p: any) => p.id === item.productId);
    if (prod) {
      prod.stock += item.quantity;
      if (isMongoConnected && mongoDb) {
        mongoDb.collection('products').updateOne(
          { id: prod.id },
          { $inc: { stock: item.quantity } }
        ).catch(console.error);
      }
    }
  }

  if (isMongoConnected && mongoDb) {
    mongoDb.collection('orders').updateOne(
      { id: order.id },
      { $set: { status: 'Cancelled', timeline: order.timeline } }
    ).catch(console.error);
  }

  res.json({ message: 'Order cancelled successfully', order });
});

// 11. Wishlist Sync
app.post('/api/wishlist/toggle', (req, res) => {
  const { userId, productId } = req.body;
  const user = memoryUsers.find(u => u.id === userId);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  const idx = user.wishlist.indexOf(productId);
  if (idx >= 0) {
    user.wishlist.splice(idx, 1);
  } else {
    user.wishlist.push(productId);
  }

  if (isMongoConnected && mongoDb) {
    mongoDb.collection('users').updateOne(
      { id: userId },
      { $set: { wishlist: user.wishlist } }
    ).catch(console.error);
  }

  res.json({ wishlist: user.wishlist });
});

// ==========================================
// VITE OR STATIC FRONTEND HOSTING
// ==========================================
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[StyleNest] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
