import { Product, Order, BackendStatus } from '../types';

export const API_BASE = '/api';

export async function fetchBackendStatus(): Promise<BackendStatus> {
  try {
    const res = await fetch(`${API_BASE}/status`);
    if (!res.ok) throw new Error('Status endpoint failed');
    return await res.json();
  } catch (err: any) {
    return {
      connected: false,
      database: 'memory-store',
      productCount: 12,
      ordersCount: 0,
      mongoUriConfigured: false,
      message: 'Running on local store. To connect live MongoDB Atlas, specify MONGODB_URI.'
    };
  }
}

export async function fetchCategories() {
  const res = await fetch(`${API_BASE}/categories`);
  if (!res.ok) throw new Error('Failed to fetch categories');
  return await res.json();
}

export interface ProductQueryParams {
  search?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  size?: string;
  color?: string;
  rating?: number;
  inStock?: boolean;
  sort?: string;
  tag?: string;
}

export async function fetchProducts(params: ProductQueryParams = {}): Promise<{ products: Product[]; total: number; source: string }> {
  const searchParams = new URLSearchParams();
  
  if (params.search) searchParams.set('search', params.search);
  if (params.category && params.category !== 'All') searchParams.set('category', params.category);
  if (params.minPrice !== undefined) searchParams.set('minPrice', String(params.minPrice));
  if (params.maxPrice !== undefined) searchParams.set('maxPrice', String(params.maxPrice));
  if (params.size && params.size !== 'All') searchParams.set('size', params.size);
  if (params.color && params.color !== 'All') searchParams.set('color', params.color);
  if (params.rating) searchParams.set('rating', String(params.rating));
  if (params.inStock) searchParams.set('inStock', 'true');
  if (params.sort) searchParams.set('sort', params.sort);
  if (params.tag) searchParams.set('tag', params.tag);

  const url = `${API_BASE}/products?${searchParams.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch products');
  return await res.json();
}

export async function fetchProductById(id: string): Promise<{ product: Product; similar: Product[] }> {
  const res = await fetch(`${API_BASE}/products/${id}`);
  if (!res.ok) throw new Error('Failed to fetch product details');
  return await res.json();
}

export async function createOrder(orderData: any): Promise<{ order: Order; message: string }> {
  const res = await fetch(`${API_BASE}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(orderData),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to place order');
  }
  return data;
}

export async function fetchUserOrders(userId?: string): Promise<{ orders: Order[] }> {
  const url = userId ? `${API_BASE}/orders?userId=${userId}` : `${API_BASE}/orders`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch orders');
  return await res.json();
}

export async function cancelOrder(orderId: string, reason?: string): Promise<{ order: Order; message: string }> {
  const res = await fetch(`${API_BASE}/orders/${orderId}/cancel`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to cancel order');
  }
  return data;
}
