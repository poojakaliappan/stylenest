import React, { useState } from 'react';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { Product } from '../types';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onQuickAdd?: (product: Product) => void;
}

export function ProductCard({ product, onSelect, onQuickAdd }: ProductCardProps) {
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();
  const [imgError, setImgError] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const isFavorited = isInWishlist(product.id);

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id, product.name);
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickAdd) {
      onQuickAdd(product);
      return;
    }
    // If sizes exist, pick default first size and color
    const defaultSize = product.sizes[0] || 'M';
    const defaultColor = product.colors[0]?.name || 'Standard';
    addToCart(product, defaultSize, defaultColor, 1);
  };

  return (
    <div
      onClick={() => onSelect(product)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative bg-white rounded-2xl border border-pink-100/80 shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col overflow-hidden"
    >
      {/* Image Container (Lead with Imagery 4:3) */}
      <div className="relative aspect-[4/5] sm:aspect-[4/5] bg-pink-50/40 overflow-hidden">
        {!imgError ? (
          <img
            src={product.images[0]}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-pink-100/60 to-purple-100/60 text-pink-700">
            <ShoppingBag className="w-10 h-10 mb-2 opacity-60 text-pink-600" />
            <span className="text-xs font-semibold">{product.name}</span>
            <span className="text-[11px] text-pink-500 mt-0.5">{product.category}</span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          type="button"
          aria-label={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
          onClick={handleHeartClick}
          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-transform duration-150 active:scale-90 shadow-xs ${
            isFavorited
              ? 'bg-rose-50 text-rose-600 shadow-rose-200/50'
              : 'bg-white/85 text-slate-600 hover:text-rose-500 hover:bg-white'
          }`}
        >
          <Heart className={`w-4 h-4 ${isFavorited ? 'fill-rose-600 text-rose-600' : ''}`} />
        </button>

        {/* Discount Tag (single, clean) */}
        {product.discountPercent > 0 && (
          <div className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-md tracking-wider shadow-xs">
            {product.discountPercent}% OFF
          </div>
        )}

        {/* Quick Add Overlay on Desktop Hover */}
        <div
          className={`absolute inset-x-2 bottom-2 hidden sm:flex items-center gap-1.5 transition-opacity duration-200 ${
            isHovered ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <button
            type="button"
            onClick={handleQuickAdd}
            className="flex-1 py-2 px-3 bg-white/95 hover:bg-white text-slate-900 rounded-xl text-xs font-semibold shadow-md flex items-center justify-center gap-1.5 border border-pink-100 transition-colors"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-pink-600" />
            Quick Add
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); onSelect(product); }}
            className="p-2 bg-slate-900/90 hover:bg-slate-900 text-white rounded-xl shadow-md transition-colors"
            title="View Details"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Details Section */}
      <div className="p-3 sm:p-4 flex flex-col flex-1 justify-between gap-1.5">
        <div>
          {/* Brand & Category in muted text */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
            <span className="uppercase tracking-wider text-pink-700/90 font-semibold">{product.brand}</span>
            <span>{product.category}</span>
          </div>

          {/* Product Name */}
          <h3 className="text-sm font-medium text-slate-900 line-clamp-2 mt-0.5 leading-snug group-hover:text-pink-600 transition-colors">
            {product.name}
          </h3>
        </div>

        <div>
          {/* Rating */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
            <div className="flex items-center gap-0.5 bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded text-[11px] font-bold">
              <span>{product.rating.toFixed(1)}</span>
              <Star className="w-3 h-3 fill-emerald-700 text-emerald-700 inline" />
            </div>
            <span className="text-[11px] text-slate-400">({product.reviewCount})</span>
            {product.stock <= 5 && product.stock > 0 && (
              <span className="text-[11px] text-rose-600 font-medium ml-auto">
                Only {product.stock} left!
              </span>
            )}
          </div>

          {/* Price Strip */}
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-base sm:text-lg font-bold text-slate-900 tabular-nums">
              ₹{product.sellingPrice.toLocaleString('en-IN')}
            </span>
            {product.originalPrice > product.sellingPrice && (
              <span className="text-xs text-slate-400 line-through tabular-nums">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {/* Sizes preview */}
          <div className="flex items-center gap-1 mt-2 text-[10px] text-slate-500">
            <span className="text-slate-400">Sizes:</span>
            {product.sizes.slice(0, 4).map(size => (
              <span key={size} className="px-1.5 py-0.5 bg-slate-100 rounded text-slate-700 font-medium">
                {size}
              </span>
            ))}
            {product.sizes.length > 4 && (
              <span className="text-slate-400">+{product.sizes.length - 4}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
