import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertTriangle, ExternalLink, X, RefreshCw, Server, ShieldCheck, Copy, Check } from 'lucide-react';
import { fetchBackendStatus } from '../services/api';
import { BackendStatus } from '../types';

interface DatabaseStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DatabaseStatusModal({ isOpen, onClose }: DatabaseStatusModalProps) {
  const [status, setStatus] = useState<BackendStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const loadStatus = async () => {
    setLoading(true);
    const data = await fetchBackendStatus();
    setStatus(data);
    setLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      loadStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const sampleMongoUri = `mongodb+srv://<username>:<password>@cluster0.abcde.mongodb.net/stylenest?retryWrites=true&w=majority`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(sampleMongoUri);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-pink-100 overflow-hidden text-slate-800"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-pink-200" />
            <div>
              <h3 className="font-semibold text-base leading-tight">Database & Backend Architecture</h3>
              <p className="text-xs text-pink-100">Live Status & MongoDB Atlas Integration</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Status Card */}
          <div className={`p-4 rounded-xl border flex items-start gap-3 ${
            status?.connected
              ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
              : 'bg-amber-50/80 border-amber-200 text-amber-900'
          }`}>
            {status?.connected ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="flex-1 text-sm">
              <div className="flex items-center justify-between font-semibold">
                <span>
                  {status?.connected ? 'Connected to MongoDB Atlas' : 'Operational Dynamic Store (Pre-configured)'}
                </span>
                <button
                  onClick={loadStatus}
                  disabled={loading}
                  className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 font-normal ml-2"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>
              <p className="text-xs mt-1 text-slate-600">
                {status?.message}
              </p>
              <div className="mt-2.5 flex flex-wrap gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-md bg-white border border-slate-200 font-medium text-slate-700">
                  Products in Catalog: <strong className="text-pink-600">{status?.productCount ?? 12}</strong>
                </span>
                <span className="px-2.5 py-1 rounded-md bg-white border border-slate-200 font-medium text-slate-700">
                  Total Orders: <strong className="text-purple-600">{status?.ordersCount ?? 0}</strong>
                </span>
                <span className="px-2.5 py-1 rounded-md bg-white border border-slate-200 font-medium text-slate-700">
                  Backend: <strong className="text-slate-900">Node.js + Express</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Architecture Requirements Matrix */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              System Architecture & Separation
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-lg bg-pink-50/50 border border-pink-100 space-y-1">
                <div className="font-semibold text-pink-900 flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-pink-600" /> Frontend (React + Vite)
                </div>
                <p className="text-slate-600">Customer shopping UI, responsive layout, cart & wishlist state.</p>
                <div className="text-[11px] text-pink-700 font-medium">Deploy target: Vercel</div>
              </div>

              <div className="p-3 rounded-lg bg-purple-50/50 border border-purple-100 space-y-1">
                <div className="font-semibold text-purple-900 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-purple-600" /> Backend (Node.js & Express)
                </div>
                <p className="text-slate-600">Stock & price verification, order processing, MongoDB connection.</p>
                <div className="text-[11px] text-purple-700 font-medium">Deploy target: Render</div>
              </div>
            </div>
          </div>

          {/* Simple Steps to Connect MongoDB Atlas */}
          <div className="space-y-3 border-t border-slate-100 pt-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              How to Connect Your MongoDB Atlas Database (3 Steps)
            </h4>

            <ol className="text-xs space-y-2 text-slate-700 list-decimal pl-4">
              <li>
                <strong>Create a free cluster on MongoDB Atlas</strong> at <a href="https://www.mongodb.com/cloud/atlas" target="_blank" rel="noreferrer" className="text-pink-600 underline inline-flex items-center gap-0.5">mongodb.com <ExternalLink className="w-3 h-3" /></a> and create a database user.
              </li>
              <li>
                <strong>Add IP Address:</strong> In Atlas Network Access, allow access from anywhere (<code className="bg-slate-100 px-1 py-0.5 rounded text-pink-700 font-mono">0.0.0.0/0</code>) so your backend can connect.
              </li>
              <li>
                <strong>Configure Environment Variable:</strong> Set your connection string in <code className="bg-slate-100 px-1 py-0.5 rounded text-pink-700 font-mono">MONGODB_URI</code> in your backend environment (or <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">.env</code>).
              </li>
            </ol>

            {/* Connection string snippet */}
            <div className="bg-slate-900 text-slate-200 p-3 rounded-xl text-xs font-mono relative">
              <div className="text-[10px] text-slate-400 mb-1">MONGODB_URI format:</div>
              <div className="break-all text-pink-300 select-all pr-8">
                {sampleMongoUri}
              </div>
              <button
                onClick={copyToClipboard}
                className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                title="Copy connection string"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200/80">
            🔒 <strong>Zero Credential Leakage:</strong> StyleNest maintains strict security separation. Database passwords and Atlas keys are accessed solely on the server side (`server.ts`) and never exposed in client-side bundles.
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
