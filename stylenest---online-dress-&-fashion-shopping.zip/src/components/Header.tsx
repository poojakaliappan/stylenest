import React, { useState } from 'react';
import { 
  Search, 
  Heart, 
  ShoppingBag, 
  User as UserIcon, 
  Package, 
  Database, 
  Sparkles,
  Menu,
  X,
  LogOut,
  ChevronDown
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';
import { ProductCategory } from '../types';

interface HeaderProps {
  currentTab: string;
  onNavigate: (tab: string, extra?: any) => void;
  onSearch: (query: string) => void;
  onOpenDatabaseStatus: () => void;
  categories: { name: string; slug: string }[];
}

export function Header({ 
  currentTab, 
  onNavigate, 
  onSearch, 
  onOpenDatabaseStatus,
  categories 
}: HeaderProps) {
  const { totalItems } = useCart();
  const { wishlistCount } = useWishlist();
  const { user, isAuthenticated, logout, openAuthModal } = useAuth();

  const [searchInput, setSearchInput] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
      onNavigate('shop');
    }
  };

  const handleCategoryClick = (categoryName: ProductCategory) => {
    onNavigate('shop', { category: categoryName });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-pink-100 shadow-xs">
      {/* 1. Top Offer Strip */}
      <div className="bg-gradient-to-r from-pink-600 via-rose-500 to-purple-600 text-white text-[11px] sm:text-xs py-1.5 px-4 font-medium text-center flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-pink-200 shrink-0" />
        <span>
          <strong>Festive Dhamaka:</strong> Free Delivery on orders above ₹499 · Extra 10% Off with code <strong>NEST10</strong>
        </span>
      </div>

      {/* 2. Main Navigation Bar (Clean 3-Zone Contract) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 -ml-1 text-slate-700 hover:text-pink-600 rounded-lg"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-left group"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xl sm:text-2xl font-bold font-serif tracking-tight bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 bg-clip-text text-transparent">
                StyleNest
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Search Bar */}
        <div className="flex-1 max-w-xl">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              placeholder="Search Kurtis, Sarees, Dresses, Tops, Jeans..."
              className="w-full bg-pink-50/50 hover:bg-pink-50/80 focus:bg-white text-slate-900 text-xs sm:text-sm pl-9 pr-12 py-2.5 rounded-full border border-pink-200/80 focus:border-pink-500 focus:outline-none focus:ring-3 focus:ring-pink-100 transition-all placeholder:text-slate-400"
            />
            <Search className="w-4 h-4 text-pink-500 absolute left-3 top-3" />
            {searchInput && (
              <button
                type="button"
                onClick={() => { setSearchInput(''); onSearch(''); }}
                className="absolute right-9 top-3 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
            <button
              type="submit"
              className="absolute right-2 top-1.5 px-2.5 py-1 bg-pink-600 hover:bg-pink-700 text-white rounded-full text-xs font-semibold shadow-xs transition-colors"
            >
              Go
            </button>
          </form>
        </div>

        {/* Zone 3: Navigation Actions */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* Database & MongoDB Status Trigger */}
          <button
            onClick={onOpenDatabaseStatus}
            title="Database Architecture & Status"
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-purple-700 bg-purple-50 hover:bg-purple-100/80 border border-purple-200/80 rounded-xl transition-colors"
          >
            <Database className="w-3.5 h-3.5 text-purple-600" />
            <span>DB Status</span>
          </button>

          {/* Orders Link */}
          <button
            onClick={() => onNavigate('orders')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
              currentTab === 'orders'
                ? 'text-pink-600 bg-pink-50'
                : 'text-slate-700 hover:text-pink-600 hover:bg-pink-50/50'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>My Orders</span>
          </button>

          {/* Wishlist Link */}
          <button
            onClick={() => onNavigate('wishlist')}
            className={`relative p-2 rounded-xl text-slate-700 hover:text-pink-600 hover:bg-pink-50 transition-colors ${
              currentTab === 'wishlist' ? 'text-pink-600 bg-pink-50' : ''
            }`}
            title="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Link */}
          <button
            onClick={() => onNavigate('cart')}
            className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
              currentTab === 'cart'
                ? 'bg-pink-600 text-white'
                : 'bg-pink-50 text-pink-700 hover:bg-pink-100'
            }`}
            title="Shopping Cart"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">Bag</span>
            {totalItems > 0 && (
              <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-full ${
                currentTab === 'cart' ? 'bg-white text-pink-600' : 'bg-pink-600 text-white'
              }`}>
                {totalItems}
              </span>
            )}
          </button>

          {/* Account Menu */}
          <div className="relative">
            {isAuthenticated && user ? (
              <div className="relative">
                <button
                  onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-pink-50 rounded-xl transition-colors"
                >
                  <div className="w-6 h-6 rounded-full bg-pink-200 text-pink-800 flex items-center justify-center text-xs font-bold uppercase">
                    {user.name.charAt(0)}
                  </div>
                  <span className="hidden md:inline max-w-[80px] truncate">{user.name.split(' ')[0]}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {accountMenuOpen && (
                  <div 
                    className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-pink-100 py-1.5 text-xs text-slate-700 z-50 animate-in fade-in"
                    onClick={() => setAccountMenuOpen(false)}
                  >
                    <div className="px-3 py-2 border-b border-slate-100">
                      <p className="font-semibold text-slate-900 truncate">{user.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                    </div>
                    <button
                      onClick={() => onNavigate('profile')}
                      className="w-full px-3 py-2 text-left hover:bg-pink-50 hover:text-pink-600 flex items-center gap-2"
                    >
                      <UserIcon className="w-3.5 h-3.5" /> My Profile
                    </button>
                    <button
                      onClick={() => onNavigate('orders')}
                      className="w-full px-3 py-2 text-left hover:bg-pink-50 hover:text-pink-600 flex items-center gap-2"
                    >
                      <Package className="w-3.5 h-3.5" /> My Orders
                    </button>
                    <button
                      onClick={() => onNavigate('wishlist')}
                      className="w-full px-3 py-2 text-left hover:bg-pink-50 hover:text-pink-600 flex items-center gap-2"
                    >
                      <Heart className="w-3.5 h-3.5" /> Wishlist
                    </button>
                    <button
                      onClick={onOpenDatabaseStatus}
                      className="w-full px-3 py-2 text-left hover:bg-pink-50 hover:text-pink-600 flex items-center gap-2 border-t border-slate-100 text-purple-700"
                    >
                      <Database className="w-3.5 h-3.5" /> DB Architecture
                    </button>
                    <button
                      onClick={logout}
                      className="w-full px-3 py-2 text-left text-rose-600 hover:bg-rose-50 flex items-center gap-2 border-t border-slate-100"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Log Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={openAuthModal}
                className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-xl text-xs font-semibold shadow-xs hover:from-pink-700 hover:to-purple-700 transition-all"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 3. Horizontal Category Ribbon */}
      <div className="border-t border-pink-100/60 bg-pink-50/20 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 sm:gap-2 py-2 text-xs font-medium text-slate-700 whitespace-nowrap">
          <button
            onClick={() => onNavigate('shop', { category: 'All' })}
            className={`px-3 py-1 rounded-full transition-colors ${
              currentTab === 'shop' ? 'bg-pink-600 text-white' : 'hover:bg-pink-100/80 hover:text-pink-700'
            }`}
          >
            All Dresses
          </button>

          {categories.map(cat => (
            <button
              key={cat.name}
              onClick={() => handleCategoryClick(cat.name as ProductCategory)}
              className="px-3 py-1 rounded-full hover:bg-pink-100/80 hover:text-pink-700 transition-colors text-slate-600"
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-pink-200 p-4 space-y-3 animate-in slide-in-from-top-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="font-semibold text-sm text-slate-900">Explore StyleNest</span>
            <button
              onClick={onOpenDatabaseStatus}
              className="text-xs text-purple-700 font-medium flex items-center gap-1"
            >
              <Database className="w-3.5 h-3.5" /> DB Status
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
              className="p-2.5 text-left rounded-lg bg-pink-50/60 font-medium text-pink-900"
            >
              🏠 Home
            </button>
            <button
              onClick={() => { onNavigate('shop'); setMobileMenuOpen(false); }}
              className="p-2.5 text-left rounded-lg bg-pink-50/60 font-medium text-pink-900"
            >
              👗 Shop All
            </button>
            <button
              onClick={() => { onNavigate('orders'); setMobileMenuOpen(false); }}
              className="p-2.5 text-left rounded-lg bg-pink-50/60 font-medium text-pink-900"
            >
              📦 My Orders
            </button>
            <button
              onClick={() => { onNavigate('wishlist'); setMobileMenuOpen(false); }}
              className="p-2.5 text-left rounded-lg bg-pink-50/60 font-medium text-pink-900"
            >
              ❤️ Wishlist ({wishlistCount})
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
