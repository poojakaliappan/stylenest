import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Phone, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export function AuthModal() {
  const { isAuthModalOpen, closeAuthModal, login, register } = useAuth();
  const { showToast } = useToast();
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        if (!email || !password) {
          throw new Error('Please enter your email and password');
        }
        await login(email, password);
        showToast('Welcome back to StyleNest!', 'success');
      } else {
        if (!name || !email || !password) {
          throw new Error('Please fill in your name, email, and password');
        }
        await register(name, email, password, phone);
        showToast('Account registered successfully! Welcome to StyleNest!', 'success');
      }
      closeAuthModal();
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
      showToast(err.message || 'Authentication error', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoFill = () => {
    setEmail('poojakaliappan490@gmail.com');
    setPassword('password123');
    setName('Pooja Kaliappan');
    setPhone('9876543210');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-pink-100 overflow-hidden text-slate-800"
        onClick={e => e.stopPropagation()}
      >
        {/* Banner */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 p-6 text-white text-center relative">
          <button
            onClick={closeAuthModal}
            className="absolute top-4 right-4 p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="w-12 h-12 bg-white/10 rounded-2xl mx-auto flex items-center justify-center mb-2 backdrop-blur-sm">
            <Sparkles className="w-6 h-6 text-pink-200" />
          </div>
          <h2 className="text-xl font-bold font-serif">StyleNest</h2>
          <p className="text-xs text-pink-100 mt-1">
            {mode === 'login' ? 'Sign in to access your orders & wishlist' : 'Create an account for personalized shopping'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 border-b border-slate-100 text-sm font-semibold">
          <button
            onClick={() => { setMode('login'); setError(null); }}
            className={`py-3 text-center transition-colors border-b-2 ${
              mode === 'login'
                ? 'border-pink-600 text-pink-600 bg-pink-50/30'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Customer Login
          </button>
          <button
            onClick={() => { setMode('register'); setError(null); }}
            className={`py-3 text-center transition-colors border-b-2 ${
              mode === 'register'
                ? 'border-pink-600 text-pink-600 bg-pink-50/30'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            New Registration
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
              {error}
            </div>
          )}

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Pooja Kaliappan"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number (Optional)</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="10-digit mobile number"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-pink-200 transition-all flex items-center justify-center gap-2"
          >
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In to StyleNest' : 'Create Free Account'}
          </button>

          {/* Quick Demo Pre-fill */}
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={handleDemoFill}
              className="text-xs text-purple-600 hover:text-purple-800 font-medium hover:underline inline-flex items-center gap-1"
            >
              Fill Demo Customer Info (Pooja Kaliappan)
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
