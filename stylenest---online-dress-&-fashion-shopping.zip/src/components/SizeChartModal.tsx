import React from 'react';
import { X, Ruler } from 'lucide-react';

interface SizeChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  category?: string;
}

export function SizeChartModal({ isOpen, onClose, category }: SizeChartModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-pink-100 overflow-hidden text-slate-800"
        onClick={e => e.stopPropagation()}
      >
        <div className="bg-gradient-to-r from-pink-600 to-purple-600 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Ruler className="w-5 h-5 text-pink-200" />
            <h3 className="font-semibold text-base">StyleNest Size Guide {category ? `(${category})` : ''}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600">
            All body measurements are indicated in inches. If you prefer a relaxed fit, we suggest choosing one size up.
          </p>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-pink-50/80 text-pink-900 border-b border-pink-100 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="py-2.5 px-3">Size</th>
                  <th className="py-2.5 px-3">Bust (in)</th>
                  <th className="py-2.5 px-3">Waist (in)</th>
                  <th className="py-2.5 px-3">Hip (in)</th>
                  <th className="py-2.5 px-3">Length (in)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr className="hover:bg-slate-50">
                  <td className="py-2 px-3 font-bold text-pink-600">XS</td>
                  <td className="py-2 px-3">32 - 33</td>
                  <td className="py-2 px-3">26 - 27</td>
                  <td className="py-2 px-3">35 - 36</td>
                  <td className="py-2 px-3">42 - 44</td>
                </tr>
                <tr className="hover:bg-slate-50 bg-pink-50/30">
                  <td className="py-2 px-3 font-bold text-pink-600">S</td>
                  <td className="py-2 px-3">34 - 35</td>
                  <td className="py-2 px-3">28 - 29</td>
                  <td className="py-2 px-3">37 - 38</td>
                  <td className="py-2 px-3">42 - 44</td>
                </tr>
                <tr className="hover:bg-slate-50">
                  <td className="py-2 px-3 font-bold text-pink-600">M</td>
                  <td className="py-2 px-3">36 - 37</td>
                  <td className="py-2 px-3">30 - 31</td>
                  <td className="py-2 px-3">39 - 40</td>
                  <td className="py-2 px-3">43 - 45</td>
                </tr>
                <tr className="hover:bg-slate-50 bg-pink-50/30">
                  <td className="py-2 px-3 font-bold text-pink-600">L</td>
                  <td className="py-2 px-3">38 - 40</td>
                  <td className="py-2 px-3">32 - 34</td>
                  <td className="py-2 px-3">41 - 43</td>
                  <td className="py-2 px-3">43 - 45</td>
                </tr>
                <tr className="hover:bg-slate-50">
                  <td className="py-2 px-3 font-bold text-pink-600">XL</td>
                  <td className="py-2 px-3">41 - 43</td>
                  <td className="py-2 px-3">35 - 37</td>
                  <td className="py-2 px-3">44 - 46</td>
                  <td className="py-2 px-3">44 - 46</td>
                </tr>
                <tr className="hover:bg-slate-50 bg-pink-50/30">
                  <td className="py-2 px-3 font-bold text-pink-600">XXL</td>
                  <td className="py-2 px-3">44 - 46</td>
                  <td className="py-2 px-3">38 - 40</td>
                  <td className="py-2 px-3">47 - 49</td>
                  <td className="py-2 px-3">44 - 46</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="bg-purple-50 p-3 rounded-lg text-xs text-purple-900 space-y-1">
            <div className="font-semibold">💡 Hassle-Free 7-Day Exchange</div>
            <p className="text-[11px] text-purple-800">
              Not sure about your size? We offer free doorstep size exchanges if the garment does not fit perfectly.
            </p>
          </div>
        </div>

        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-pink-600 hover:bg-pink-700 rounded-lg transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
}
