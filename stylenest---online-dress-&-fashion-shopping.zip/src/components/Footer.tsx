import React from 'react';
import { 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  BadgePercent, 
  ShoppingBag, 
  Heart,
  Database,
  ExternalLink
} from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string, extra?: any) => void;
  onOpenDatabaseStatus: () => void;
}

export function Footer({ onNavigate, onOpenDatabaseStatus }: FooterProps) {
  return (
    <footer className="bg-white border-t border-pink-100 text-slate-600 text-xs mt-16 pb-16 sm:pb-8">
      {/* 1. Value Badges (Meesho/Flipkart customer promises) */}
      <div className="bg-pink-50/50 border-b border-pink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm">Free Delivery</div>
              <div className="text-[11px] text-slate-500">On all orders above ₹499</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm">Cash on Delivery</div>
              <div className="text-[11px] text-slate-500">Pay cash at your doorstep</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm">7-Day Easy Returns</div>
              <div className="text-[11px] text-slate-500">Doorstep pickup & exchange</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center shrink-0">
              <BadgePercent className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm">Lowest Price Guarantee</div>
              <div className="text-[11px] text-slate-500">Direct from fashion makers</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white">
              <ShoppingBag className="w-3.5 h-3.5" />
            </div>
            <span className="text-lg font-bold font-serif bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 bg-clip-text text-transparent">
              StyleNest
            </span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            India's favorite online dress shopping destination. Curated kurtis, sarees, tops, and dresses with unbeatable factory-direct pricing.
          </p>
          <div className="mt-4 flex items-center gap-2">
            <button
              onClick={onOpenDatabaseStatus}
              className="px-2.5 py-1 text-[11px] font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Database className="w-3 h-3" /> MongoDB Atlas Architecture
            </button>
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Popular Categories</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onNavigate('shop', { category: 'Kurtis' })} className="hover:text-pink-600">
                Anarkali & Straight Kurtis
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', { category: 'Sarees' })} className="hover:text-pink-600">
                Organza & Silk Sarees
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', { category: 'Dresses' })} className="hover:text-pink-600">
                Tiered Midis & Maxi Dresses
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', { category: 'Tops' })} className="hover:text-pink-600">
                Schiffli & Peplum Tops
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('shop', { category: 'Traditional Wear' })} className="hover:text-pink-600">
                Wedding Lehenga Cholis
              </button>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Customer Care</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onNavigate('orders')} className="hover:text-pink-600">
                Track My Orders
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('wishlist')} className="hover:text-pink-600">
                My Saved Wishlist
              </button>
            </li>
            <li>
              <span className="text-slate-500">Shipping & Returns Policy</span>
            </li>
            <li>
              <span className="text-slate-500">Size & Fit Measuring Guide</span>
            </li>
            <li>
              <span className="text-slate-500">Contact: support@stylenest.in</span>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Backend & Cloud Tech</h4>
          <div className="space-y-2 text-[11px] text-slate-500">
            <p><strong>Frontend:</strong> React + Vite on Vercel</p>
            <p><strong>Backend API:</strong> Node.js + Express on Render</p>
            <p><strong>Database:</strong> MongoDB Atlas Cloud</p>
            <p><strong>Images:</strong> Cloudinary / Web CDN</p>
            <div className="pt-2 text-pink-700 font-medium">
              Real-time stock validation and server-computed order pricing.
            </div>
          </div>
        </div>
      </div>

      {/* 3. Copyright bar */}
      <div className="border-t border-slate-100 py-4 text-center text-[11px] text-slate-400">
        <p>© 2026 StyleNest Fashion Retail. Crafted with care for dress lovers across India.</p>
      </div>
    </footer>
  );
}
