import React from 'react';
import { Home, Grid, Package, Heart, ShoppingBag, User } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';

interface MobileBottomNavProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
}

export function MobileBottomNav({ currentTab, onNavigate }: MobileBottomNavProps) {
  const { totalItems } = useCart();
  const { wishlistCount } = useWishlist();
  const { isAuthenticated, openAuthModal } = useAuth();

  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-pink-100 flex items-center justify-around py-2 px-1 shadow-lg text-[10px]">
      <button
        onClick={() => onNavigate('home')}
        className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'home' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <Home className="w-5 h-5" />
        <span>Home</span>
      </button>

      <button
        onClick={() => onNavigate('shop')}
        className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'shop' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <Grid className="w-5 h-5" />
        <span>Categories</span>
      </button>

      <button
        onClick={() => onNavigate('orders')}
        className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'orders' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <Package className="w-5 h-5" />
        <span>Orders</span>
      </button>

      <button
        onClick={() => onNavigate('wishlist')}
        className={`relative flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'wishlist' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <Heart className="w-5 h-5" />
        <span>Wishlist</span>
        {wishlistCount > 0 && (
          <span className="absolute top-0 right-2 w-3.5 h-3.5 bg-rose-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
            {wishlistCount}
          </span>
        )}
      </button>

      <button
        onClick={() => onNavigate('cart')}
        className={`relative flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'cart' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <ShoppingBag className="w-5 h-5" />
        <span>Bag</span>
        {totalItems > 0 && (
          <span className="absolute top-0 right-2 w-3.5 h-3.5 bg-pink-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
            {totalItems}
          </span>
        )}
      </button>

      <button
        onClick={() => {
          if (isAuthenticated) {
            onNavigate('profile');
          } else {
            openAuthModal();
          }
        }}
        className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors ${
          currentTab === 'profile' ? 'text-pink-600 font-bold' : 'text-slate-600'
        }`}
      >
        <User className="w-5 h-5" />
        <span>Account</span>
      </button>
    </nav>
  );
}
