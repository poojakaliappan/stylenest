import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  TrendingUp, 
  Flame, 
  Award, 
  Percent, 
  ChevronRight,
  ShieldCheck,
  Truck,
  RotateCcw
} from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { ProductCard } from '../components/ProductCard';
import { fetchProducts } from '../services/api';

interface HomePageProps {
  onSelectProduct: (product: Product) => void;
  onNavigate: (tab: string, extra?: any) => void;
  onOpenDatabaseStatus: () => void;
}

export function HomePage({ onSelectProduct, onNavigate, onOpenDatabaseStatus }: HomePageProps) {
  const [activeTab, setActiveTab] = useState<'trending' | 'new-arrivals' | 'best-sellers' | 'special-offers'>('trending');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Category bubbles
  const categoryHighlights = [
    { name: 'Kurtis', image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=400&q=80', tag: 'From ₹499' },
    { name: 'Sarees', image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=400&q=80', tag: 'Min 50% Off' },
    { name: 'Dresses', image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=400&q=80', tag: 'Tiered Midis' },
    { name: 'Tops', image: 'https://images.unsplash.com/photo-1589310243389-96a5483213a8?auto=format&fit=crop&w=400&q=80', tag: 'From ₹349' },
    { name: 'Jeans', image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=400&q=80', tag: 'Wide-Leg' },
    { name: 'Leggings', image: 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=400&q=80', tag: 'Pack of 2' },
    { name: 'Nightwear', image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=400&q=80', tag: 'Satin Sets' },
    { name: 'Traditional Wear', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=400&q=80', tag: 'Lehengas' },
  ];

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const data = await fetchProducts({ tag: activeTab });
        setProducts(data.products);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [activeTab]);

  return (
    <div className="space-y-8 sm:space-y-12">
      {/* 1. Hero Fashion Campaign Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white shadow-xl shadow-pink-500/10">
        <div className="max-w-7xl mx-auto px-6 py-10 sm:py-16 md:py-20 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4 sm:space-y-6 z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/20 backdrop-blur-md text-pink-100 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Festive Season 2026 Collection</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-serif tracking-tight leading-tight">
              Flattering Dresses &amp; Ethnic Wear <br />
              <span className="text-pink-100 font-sans font-light text-2xl sm:text-3xl md:text-4xl">
                At Direct Factory Prices
              </span>
            </h1>

            <p className="text-sm sm:text-base text-pink-100/90 max-w-lg leading-relaxed">
              Explore 500+ handcrafted Kurtis, Sarees, Western Midis, and Festive Lehengas with easy Cash on Delivery and 7-day free exchange.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('shop')}
                className="px-6 py-3 bg-white text-pink-700 hover:bg-pink-50 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform hover:-translate-y-0.5 active:scale-95 flex items-center gap-2"
              >
                <span>Shop All Dresses</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('shop', { category: 'Kurtis' })}
                className="px-5 py-3 bg-white/15 hover:bg-white/25 text-white font-semibold text-xs sm:text-sm rounded-xl backdrop-blur-md transition-colors"
              >
                Explore Kurtis
              </button>
            </div>

            {/* Quick mini trust strip */}
            <div className="pt-3 flex items-center gap-4 text-[11px] text-pink-100/80">
              <span className="flex items-center gap-1"><Truck className="w-3.5 h-3.5" /> Free Shipping ₹499+</span>
              <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> COD Available</span>
              <span className="flex items-center gap-1"><RotateCcw className="w-3.5 h-3.5" /> Easy 7-Day Returns</span>
            </div>
          </div>

          {/* Hero Image Showcase */}
          <div className="relative flex justify-center md:justify-end">
            <div className="relative w-full max-w-sm sm:max-w-md aspect-[4/3] sm:aspect-[16/10] rounded-2xl overflow-hidden shadow-2xl border-4 border-white/20">
              <img
                src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80"
                alt="StyleNest Festive Dress Collection"
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                <div className="text-white text-xs">
                  <div className="font-bold text-sm">Blush Pink Anarkali Edit</div>
                  <div className="text-pink-200 text-[11px]">Special Festive Edition · Flat 57% Off</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Category Bubble Highlights (Meesho/Flipkart category row) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-serif">
              Shop By Category
            </h2>
            <p className="text-xs text-slate-500">Pick from our best-loved wardrobe essentials</p>
          </div>
          <button
            onClick={() => onNavigate('shop')}
            className="text-xs font-semibold text-pink-600 hover:text-pink-700 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-3 sm:gap-4">
          {categoryHighlights.map(cat => (
            <button
              key={cat.name}
              onClick={() => onNavigate('shop', { category: cat.name })}
              className="group flex flex-col items-center text-center p-2 rounded-2xl bg-white hover:bg-pink-50/60 border border-pink-100/60 transition-all hover:shadow-md"
            >
              <div className="w-14 h-14 sm:w-18 sm:h-18 rounded-full overflow-hidden border-2 border-pink-200 group-hover:border-pink-500 transition-colors bg-pink-100/50 shadow-xs mb-2">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <span className="text-xs font-semibold text-slate-800 group-hover:text-pink-600 leading-tight">
                {cat.name}
              </span>
              <span className="text-[10px] text-pink-600 font-medium mt-0.5">
                {cat.tag}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* 3. Curated Tabs (New Arrivals, Trending, Best Sellers, Special Offers) */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-pink-100 pb-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              Curated Dress Collections
            </h2>
            <p className="text-xs text-slate-500">Hand-picked designs loved by 50,000+ customers</p>
          </div>

          {/* Interactive filter tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-pink-50/80 rounded-xl overflow-x-auto scrollbar-none">
            <button
              onClick={() => setActiveTab('trending')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'trending'
                  ? 'bg-white text-pink-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-pink-500" />
              Trending Dresses
            </button>

            <button
              onClick={() => setActiveTab('new-arrivals')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'new-arrivals'
                  ? 'bg-white text-pink-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-rose-500" />
              New Arrivals
            </button>

            <button
              onClick={() => setActiveTab('best-sellers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'best-sellers'
                  ? 'bg-white text-pink-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-purple-500" />
              Best Sellers
            </button>

            <button
              onClick={() => setActiveTab('special-offers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'special-offers'
                  ? 'bg-white text-pink-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Percent className="w-3.5 h-3.5 text-amber-500" />
              Under ₹799 Offers
            </button>
          </div>
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <div key={i} className="animate-pulse bg-white rounded-2xl p-3 border border-pink-100">
                <div className="aspect-[4/5] bg-pink-100/50 rounded-xl mb-3" />
                <div className="h-4 bg-pink-100/60 rounded w-2/3 mb-2" />
                <div className="h-3 bg-pink-100/40 rounded w-full mb-3" />
                <div className="h-5 bg-pink-100/50 rounded w-1/3" />
              </div>
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {products.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onSelect={onSelectProduct}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-2xl border border-pink-100 p-8">
            <p className="text-sm text-slate-500">No dresses found in this section right now.</p>
            <button
              onClick={() => setActiveTab('trending')}
              className="mt-3 px-4 py-2 bg-pink-600 text-white text-xs font-semibold rounded-xl"
            >
              View Trending Dresses
            </button>
          </div>
        )}
      </section>

      {/* 4. Promotional Banner (Special festive coupon) */}
      <section className="bg-gradient-to-r from-purple-900 via-pink-900 to-rose-900 text-white rounded-3xl p-6 sm:p-10 relative overflow-hidden">
        <div className="relative z-10 max-w-xl space-y-3">
          <span className="text-xs uppercase tracking-wider text-pink-300 font-semibold">Special Offer</span>
          <h3 className="text-2xl sm:text-3xl font-serif font-bold">
            Get Extra 10% Off On Your First Dress Order
          </h3>
          <p className="text-xs sm:text-sm text-pink-200">
            Use coupon code <strong className="text-white bg-white/20 px-2 py-0.5 rounded font-mono">NEST10</strong> at checkout. Valid across all Sarees, Kurtis, and Western Dresses.
          </p>
          <div className="pt-2">
            <button
              onClick={() => onNavigate('shop')}
              className="px-5 py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl text-xs font-bold shadow-md transition-colors"
            >
              Claim Discount Now
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
