import React, { useState, useEffect } from 'react';
import { Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { Product, ProductSize } from '../types';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { fetchProducts } from '../services/api';

interface WishlistPageProps {
  onSelectProduct: (product: Product) => void;
  onNavigate: (tab: string, extra?: any) => void;
}

export function WishlistPage({ onSelectProduct, onNavigate }: WishlistPageProps) {
  const { wishlistIds, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();
  const [wishlistProducts, setWishlistProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Quick move to cart modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [chosenSize, setChosenSize] = useState<ProductSize | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const res = await fetchProducts();
        const filtered = res.products.filter(p => wishlistIds.includes(p.id));
        setWishlistProducts(filtered);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [wishlistIds]);

  const handleOpenMoveToCart = (product: Product) => {
    setSelectedProduct(product);
    setChosenSize(product.sizes[0] || 'M');
  };

  const handleConfirmMoveToCart = () => {
    if (!selectedProduct || !chosenSize) return;
    const defaultColor = selectedProduct.colors[0]?.name || 'Standard';
    const success = addToCart(selectedProduct, chosenSize, defaultColor, 1);
    if (success) {
      toggleWishlist(selectedProduct.id);
      setSelectedProduct(null);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-pink-100">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900">
            My Wishlist ({wishlistIds.length})
          </h1>
          <p className="text-xs text-slate-500">Your favorite dresses saved for later</p>
        </div>
        <button
          onClick={() => onNavigate('shop')}
          className="text-xs font-semibold text-pink-600 hover:text-pink-700"
        >
          Explore More Dresses
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="animate-pulse bg-white rounded-2xl p-3 border border-pink-100">
              <div className="aspect-[4/5] bg-pink-100/50 rounded-xl mb-3" />
              <div className="h-4 bg-pink-100 rounded w-2/3 mb-2" />
              <div className="h-5 bg-pink-100 rounded w-1/3" />
            </div>
          ))}
        </div>
      ) : wishlistProducts.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-pink-100 text-center space-y-4 max-w-md mx-auto">
          <div className="w-16 h-16 bg-pink-50 text-pink-600 rounded-full flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-bold text-slate-900">Your Wishlist is Empty</h3>
            <p className="text-xs text-slate-500">
              Tap the heart icon on any kurti, saree, or dress to save it here for later.
            </p>
          </div>
          <button
            onClick={() => onNavigate('shop')}
            className="px-5 py-2.5 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-bold text-xs rounded-xl shadow-md"
          >
            Browse Trending Dresses
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
          {wishlistProducts.map(product => (
            <div
              key={product.id}
              className="bg-white rounded-2xl border border-pink-100 shadow-xs overflow-hidden flex flex-col justify-between group"
            >
              <div 
                className="relative aspect-[4/5] bg-pink-50 cursor-pointer overflow-hidden"
                onClick={() => onSelectProduct(product)}
              >
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id, product.name); }}
                  className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-white/90 text-rose-600 shadow-sm hover:bg-white"
                  title="Remove from wishlist"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                {product.discountPercent > 0 && (
                  <div className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                    {product.discountPercent}% OFF
                  </div>
                )}
              </div>

              <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-pink-600">{product.brand}</span>
                  <h3 
                    onClick={() => onSelectProduct(product)}
                    className="text-xs sm:text-sm font-semibold text-slate-900 line-clamp-2 cursor-pointer hover:text-pink-600"
                  >
                    {product.name}
                  </h3>
                </div>

                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-sm sm:text-base font-bold text-slate-900 tabular-nums">
                      ₹{product.sellingPrice.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400 line-through tabular-nums">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>

                  <button
                    onClick={() => handleOpenMoveToCart(product)}
                    className="w-full mt-2 py-2 px-3 bg-pink-50 hover:bg-pink-100 text-pink-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 border border-pink-200 transition-colors"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move to Bag</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Select Size Modal for Move to Cart */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4 text-slate-800 shadow-xl border border-pink-100">
            <h3 className="font-bold text-sm text-slate-900">Select Size for Bag</h3>
            <p className="text-xs text-slate-600 line-clamp-1">{selectedProduct.name}</p>

            <div className="flex flex-wrap gap-2 pt-1">
              {selectedProduct.sizes.map(size => (
                <button
                  key={size}
                  onClick={() => setChosenSize(size)}
                  className={`w-11 h-9 rounded-xl border text-xs font-bold transition-all ${
                    chosenSize === size
                      ? 'bg-pink-600 text-white border-pink-600'
                      : 'border-slate-200 text-slate-800 hover:border-pink-300'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setSelectedProduct(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmMoveToCart}
                className="px-4 py-2 text-xs font-bold text-white bg-pink-600 hover:bg-pink-700 rounded-xl shadow-xs"
              >
                Add to Bag
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
