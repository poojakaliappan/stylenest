import React from 'react';
import { CheckCircle2, Package, Truck, ArrowRight, ShoppingBag, MapPin } from 'lucide-react';
import { Order } from '../types';

interface OrderConfirmationPageProps {
  order: Order;
  onNavigate: (tab: string, extra?: any) => void;
}

export function OrderConfirmationPage({ order, onNavigate }: OrderConfirmationPageProps) {
  return (
    <div className="max-w-2xl mx-auto py-8 sm:py-12 px-4 space-y-8 animate-in fade-in">
      {/* Celebration Header */}
      <div className="bg-white p-8 rounded-3xl border border-pink-100 shadow-sm text-center space-y-4">
        <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-1">
          <span className="text-xs uppercase tracking-widest text-pink-600 font-bold">
            Order Confirmed
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
            Thank you for shopping with StyleNest!
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
            Your dress order has been received and sent to the seller for swift packaging.
          </p>
        </div>

        {/* Order ID Pill */}
        <div className="inline-flex items-center gap-2 bg-pink-50 text-pink-800 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold border border-pink-200">
          <Package className="w-4 h-4 text-pink-600" />
          <span>Order Number: <strong className="font-mono text-slate-900">{order.orderNumber}</strong></span>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-100 text-xs text-left">
          <div className="p-3 bg-pink-50/40 rounded-xl">
            <span className="text-slate-400 block text-[11px]">Estimated Delivery</span>
            <span className="font-bold text-slate-800 flex items-center gap-1.5 mt-0.5">
              <Truck className="w-3.5 h-3.5 text-pink-600" />
              {order.estimatedDelivery}
            </span>
          </div>

          <div className="p-3 bg-pink-50/40 rounded-xl">
            <span className="text-slate-400 block text-[11px]">Payment Mode</span>
            <span className="font-bold text-slate-800 mt-0.5 block">
              {order.paymentMethod} ({order.paymentStatus})
            </span>
          </div>
        </div>
      </div>

      {/* Delivery Address & Order Items Recap */}
      <div className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xs space-y-4 text-xs">
        <div className="flex items-start gap-2.5 pb-3 border-b border-slate-100">
          <MapPin className="w-4 h-4 text-pink-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-slate-900 text-sm">Delivering to:</div>
            <p className="text-slate-700 font-medium">{order.shippingAddress.fullName} · {order.shippingAddress.phone}</p>
            <p className="text-slate-500">
              {order.shippingAddress.street}, {order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pincode}
            </p>
          </div>
        </div>

        <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
          Ordered Garments ({order.items.length})
        </h3>

        <div className="divide-y divide-slate-100">
          {order.items.map((item, idx) => (
            <div key={idx} className="py-2.5 flex items-center gap-3">
              <img src={item.image} alt={item.name} className="w-12 h-14 object-cover rounded-lg bg-pink-50 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-800 truncate">{item.name}</p>
                <p className="text-[11px] text-slate-500">Size: {item.size} · Color: {item.color} · Qty: {item.quantity}</p>
              </div>
              <span className="font-bold text-slate-900 tabular-nums">
                ₹{(item.price * item.quantity).toLocaleString('en-IN')}
              </span>
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-slate-100 flex justify-between font-bold text-sm text-slate-900">
          <span>Total Paid / Payable on Delivery</span>
          <span className="text-pink-600 tabular-nums">₹{order.totalAmount.toLocaleString('en-IN')}</span>
        </div>
      </div>

      {/* CTA Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => onNavigate('orders')}
          className="flex-1 py-3 px-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
        >
          <Package className="w-4 h-4" />
          <span>Track in My Orders</span>
        </button>

        <button
          onClick={() => onNavigate('shop')}
          className="flex-1 py-3 px-4 bg-white hover:bg-pink-50 text-slate-700 border border-slate-200 font-bold text-xs sm:text-sm rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          <ShoppingBag className="w-4 h-4 text-pink-600" />
          <span>Continue Shopping</span>
        </button>
      </div>
    </div>
  );
}
