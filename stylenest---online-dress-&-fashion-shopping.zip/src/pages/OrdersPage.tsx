import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Calendar, 
  Truck, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  AlertTriangle,
  RotateCcw,
  ArrowRight
} from 'lucide-react';
import { Order } from '../types';
import { fetchUserOrders, cancelOrder } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

interface OrdersPageProps {
  onNavigate: (tab: string, extra?: any) => void;
}

export function OrdersPage({ onNavigate }: OrdersPageProps) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('Found better price elsewhere');

  const loadOrders = async () => {
    setLoading(true);
    try {
      const data = await fetchUserOrders(user?.id);
      setOrders(data.orders);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [user]);

  const handleOpenCancelModal = (orderId: string) => {
    setCancellingId(orderId);
    setCancelModalOpen(true);
  };

  const handleConfirmCancel = async () => {
    if (!cancellingId) return;
    try {
      await cancelOrder(cancellingId, cancelReason);
      showToast('Order cancelled successfully. Refund/Restock initialized.', 'info');
      setCancelModalOpen(false);
      setCancellingId(null);
      loadOrders();
    } catch (err: any) {
      showToast(err.message || 'Cannot cancel order', 'error');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Placed':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Confirmed':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Shipped':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Delivered':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Cancelled':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-pink-100">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900">
            My Orders
          </h1>
          <p className="text-xs text-slate-500">Track and manage your dress purchases</p>
        </div>
        <button
          onClick={() => onNavigate('shop')}
          className="text-xs font-semibold text-pink-600 hover:text-pink-700"
        >
          + Continue Shopping
        </button>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map(i => (
            <div key={i} className="animate-pulse bg-white rounded-3xl p-6 border border-pink-100 space-y-4">
              <div className="h-5 bg-pink-100 rounded w-1/3" />
              <div className="h-20 bg-pink-50 rounded" />
            </div>
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-pink-100 text-center space-y-4">
          <div className="w-16 h-16 bg-pink-50 text-pink-600 rounded-full flex items-center justify-center mx-auto">
            <Package className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-bold text-slate-900">No Orders Placed Yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Your placed orders will show up here along with live tracking and doorstep delivery status.
            </p>
          </div>
          <button
            onClick={() => onNavigate('shop')}
            className="px-5 py-2.5 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-bold text-xs rounded-xl shadow-md"
          >
            Start Shopping
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map(order => {
            const canCancel = order.status === 'Placed' || order.status === 'Confirmed';

            return (
              <div
                key={order.id}
                className="bg-white rounded-3xl border border-pink-100/90 shadow-xs p-5 sm:p-6 space-y-5 overflow-hidden"
              >
                {/* Header Strip */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 font-mono text-sm">{order.orderNumber}</span>
                      <span className={`px-2.5 py-0.5 rounded-full border text-[11px] font-bold ${getStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Placed on {new Date(order.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-900 tabular-nums">
                      ₹{order.totalAmount.toLocaleString('en-IN')}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {order.paymentMethod} ({order.paymentStatus})
                    </div>
                  </div>
                </div>

                {/* Items List */}
                <div className="divide-y divide-slate-100">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="py-3 first:pt-0 flex items-center gap-4 text-xs">
                      <img src={item.image} alt={item.name} className="w-14 h-16 object-cover rounded-xl bg-pink-50 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-slate-900 line-clamp-1">{item.name}</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Size: <strong className="text-slate-700">{item.size}</strong> · Colour: <strong className="text-slate-700">{item.color}</strong> · Qty: <strong className="text-slate-700">{item.quantity}</strong>
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-900 tabular-nums">
                          ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Order Status Tracking Stepper */}
                {order.status !== 'Cancelled' ? (
                  <div className="p-4 bg-pink-50/40 rounded-2xl border border-pink-100/60 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800 flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-pink-600" />
                        Delivery Status: <strong className="text-pink-700">{order.status}</strong>
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Est. Arrival: <strong>{order.estimatedDelivery}</strong>
                      </span>
                    </div>

                    {/* Progress Bar Stepper */}
                    <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[10px]">
                      {['Placed', 'Confirmed', 'Shipped', 'Delivered'].map((step, idx) => {
                        const steps = ['Placed', 'Confirmed', 'Shipped', 'Delivered'];
                        const currentIdx = steps.indexOf(order.status);
                        const isCompleted = idx <= currentIdx;
                        const isCurrent = idx === currentIdx;

                        return (
                          <div key={step} className="space-y-1">
                            <div className={`h-1.5 rounded-full ${
                              isCompleted ? 'bg-pink-600' : 'bg-slate-200'
                            }`} />
                            <span className={`block font-medium ${
                              isCurrent ? 'text-pink-700 font-bold' : isCompleted ? 'text-slate-700' : 'text-slate-400'
                            }`}>
                              {step}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>This order has been cancelled. Inventory has been restored.</span>
                  </div>
                )}

                {/* Footer Actions (Cancel order if eligible) */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                  <div className="text-slate-500 text-[11px]">
                    Delivery Address: {order.shippingAddress.city}, {order.shippingAddress.state} ({order.shippingAddress.pincode})
                  </div>

                  {canCancel && (
                    <button
                      onClick={() => handleOpenCancelModal(order.id)}
                      className="text-xs text-rose-600 hover:text-rose-800 hover:bg-rose-50 font-semibold px-3 py-1.5 rounded-lg border border-rose-200 transition-colors"
                    >
                      Cancel Order
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cancel Order Confirmation Modal */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 text-slate-800 shadow-2xl border border-pink-100">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-base">
              <AlertTriangle className="w-5 h-5" />
              <span>Confirm Order Cancellation</span>
            </div>

            <p className="text-xs text-slate-600">
              Are you sure you want to cancel this order? Once cancelled, the items will be returned to stock.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Reason for Cancellation
              </label>
              <select
                value={cancelReason}
                onChange={e => setCancelReason(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-pink-500"
              >
                <option value="Found better price elsewhere">Found better price elsewhere</option>
                <option value="Ordered wrong size or colour by mistake">Ordered wrong size or colour by mistake</option>
                <option value="Delivery time is too long">Delivery time is too long</option>
                <option value="Changed my mind">Changed my mind</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-xl"
              >
                Keep Order
              </button>
              <button
                onClick={handleConfirmCancel}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
              >
                Yes, Cancel Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
