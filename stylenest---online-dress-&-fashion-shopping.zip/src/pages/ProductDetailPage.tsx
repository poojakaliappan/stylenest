import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Star, 
  ShoppingBag, 
  Zap, 
  Truck, 
  RotateCcw, 
  ShieldCheck, 
  Ruler, 
  Plus, 
  Minus, 
  ChevronRight, 
  Share2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Product, ProductSize } from '../types';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useToast } from '../context/ToastContext';
import { SizeChartModal } from '../components/SizeChartModal';
import { ProductCard } from '../components/ProductCard';
import { fetchProductById } from '../services/api';

interface ProductDetailPageProps {
  productId: string;
  onSelectProduct: (product: Product) => void;
  onNavigate: (tab: string, extra?: any) => void;
  onBuyNow: (product: Product, size: ProductSize, color: string, quantity: number) => void;
}

export function ProductDetailPage({ 
  productId, 
  onSelectProduct, 
  onNavigate,
  onBuyNow 
}: ProductDetailPageProps) {
  const [product, setProduct] = useState<Product | null>(null);
  const [similarProducts, setSimilarProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // User Variant Selections
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<ProductSize | null>(null);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [validationError, setValidationError] = useState<string | null>(null);

  // PIN code check simulator
  const [pincode, setPincode] = useState('560001');
  const [deliveryResult, setDeliveryResult] = useState<string | null>(
    'Delivery in 3 to 4 days · Cash on Delivery available'
  );

  const [sizeChartOpen, setSizeChartOpen] = useState(false);

  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { showToast } = useToast();

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const data = await fetchProductById(productId);
        setProduct(data.product);
        setSimilarProducts(data.similar || []);
        setActiveImageIndex(0);
        // Reset or initialize variants
        setSelectedSize(null);
        setSelectedColor(data.product.colors[0]?.name || null);
        setQuantity(1);
        setValidationError(null);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [productId]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 animate-pulse space-y-8">
        <div className="h-6 bg-pink-100 rounded w-1/4" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="aspect-[4/5] bg-pink-100 rounded-2xl" />
          <div className="space-y-4">
            <div className="h-8 bg-pink-100 rounded w-3/4" />
            <div className="h-6 bg-pink-100 rounded w-1/3" />
            <div className="h-12 bg-pink-100 rounded w-full" />
            <div className="h-24 bg-pink-100 rounded w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-16 bg-white rounded-2xl border border-pink-100 p-8 space-y-4">
        <p className="text-base text-slate-600">Product details could not be found.</p>
        <button
          onClick={() => onNavigate('shop')}
          className="px-4 py-2 bg-pink-600 text-white text-xs font-semibold rounded-xl"
        >
          Return to Dress Shop
        </button>
      </div>
    );
  }

  const isFavorited = isInWishlist(product.id);

  const validateSelections = (): boolean => {
    if (!selectedSize) {
      setValidationError('Please select a size (XS, S, M, L, XL, XXL) before proceeding.');
      showToast('Please select a size first', 'error');
      return false;
    }
    if (!selectedColor) {
      setValidationError('Please select a colour option.');
      showToast('Please select a colour first', 'error');
      return false;
    }
    setValidationError(null);
    return true;
  };

  const handleAddToCart = () => {
    if (!validateSelections()) return;
    addToCart(product, selectedSize!, selectedColor!, quantity);
  };

  const handleBuyNowClick = () => {
    if (!validateSelections()) return;
    onBuyNow(product, selectedSize!, selectedColor!, quantity);
  };

  const checkPincode = (e: React.FormEvent) => {
    e.preventDefault();
    if (pincode.length === 6) {
      setDeliveryResult(`Estimated delivery by 3-4 days to ${pincode} · Free COD Available`);
    } else {
      setDeliveryResult('Please enter a valid 6-digit PIN code.');
    }
  };

  return (
    <div className="space-y-12">
      {/* 1. Breadcrumbs */}
      <nav className="flex items-center gap-1.5 text-xs text-slate-500">
        <button onClick={() => onNavigate('home')} className="hover:text-pink-600">Home</button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <button onClick={() => onNavigate('shop', { category: product.category })} className="hover:text-pink-600">
          {product.category}
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-slate-800 font-medium truncate max-w-[200px]">{product.name}</span>
      </nav>

      {/* 2. Product Main Container (Contiguous Purchase Module) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Gallery (Sticky on Desktop) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Main Selected Image */}
          <div className="relative aspect-[4/5] bg-pink-50/50 rounded-2xl overflow-hidden border border-pink-100/80 shadow-xs">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover object-top"
            />
            
            {/* Wishlist Button */}
            <button
              onClick={() => toggleWishlist(product.id, product.name)}
              className={`absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md shadow-md transition-all active:scale-90 ${
                isFavorited
                  ? 'bg-rose-50 text-rose-600'
                  : 'bg-white/90 text-slate-700 hover:text-rose-500 hover:bg-white'
              }`}
            >
              <Heart className={`w-5 h-5 ${isFavorited ? 'fill-rose-600 text-rose-600' : ''}`} />
            </button>

            {product.discountPercent > 0 && (
              <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs font-bold px-2.5 py-1 rounded-md tracking-wider shadow-sm">
                {product.discountPercent}% OFF
              </div>
            )}
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-20 aspect-[4/5] rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                    activeImageIndex === idx
                      ? 'border-pink-600 ring-2 ring-pink-100 scale-102'
                      : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Angle ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Purchase & Details Module */}
        <div className="lg:col-span-6 space-y-6">
          {/* Brand & Title */}
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-pink-600 font-bold">
                {product.brand}
              </span>
              <span className="text-xs text-slate-400 font-medium">{product.category}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 mt-1">
              {product.name}
            </h1>
          </div>

          {/* Rating Strip */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg text-xs font-bold">
              <span>{product.rating.toFixed(1)}</span>
              <Star className="w-3.5 h-3.5 fill-emerald-700 text-emerald-700" />
            </div>
            <span className="text-xs text-slate-500">
              {product.reviewCount} Ratings &amp; {product.reviews.length} Verified Customer Reviews
            </span>
          </div>

          {/* Price Box */}
          <div className="p-4 rounded-2xl bg-pink-50/50 border border-pink-100 space-y-1">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                ₹{product.sellingPrice.toLocaleString('en-IN')}
              </span>
              {product.originalPrice > product.sellingPrice && (
                <>
                  <span className="text-sm text-slate-400 line-through tabular-nums">
                    M.R.P. ₹{product.originalPrice.toLocaleString('en-IN')}
                  </span>
                  <span className="text-sm font-bold text-rose-600">
                    ({product.discountPercent}% Off)
                  </span>
                </>
              )}
            </div>
            <p className="text-[11px] text-slate-500">Inclusive of all taxes · Lowest price verified</p>
          </div>

          {/* Validation Alert */}
          {validationError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Colour Swatches */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
              <span>Select Colour: <strong className="text-pink-600">{selectedColor || 'Please choose'}</strong></span>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {product.colors.map(col => (
                <button
                  key={col.name}
                  onClick={() => { setSelectedColor(col.name); setValidationError(null); }}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-2 transition-all ${
                    selectedColor === col.name
                      ? 'border-pink-600 bg-pink-50 text-pink-700 ring-2 ring-pink-100 shadow-xs'
                      : 'border-slate-200 text-slate-700 hover:border-pink-300'
                  }`}
                >
                  <span 
                    className="w-3.5 h-3.5 rounded-full border border-slate-300"
                    style={{ backgroundColor: col.hex }}
                  />
                  <span>{col.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector with Size Chart */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
              <span>Select Size: <strong className="text-pink-600">{selectedSize || 'Required'}</strong></span>
              <button
                type="button"
                onClick={() => setSizeChartOpen(true)}
                className="text-pink-600 hover:text-pink-700 flex items-center gap-1 font-semibold"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Size Chart</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {product.sizes.map(size => (
                <button
                  key={size}
                  onClick={() => { setSelectedSize(size); setValidationError(null); }}
                  className={`w-12 h-10 rounded-xl border text-xs font-bold transition-all flex items-center justify-center ${
                    selectedSize === size
                      ? 'bg-pink-600 text-white border-pink-600 shadow-xs'
                      : 'bg-white text-slate-800 border-slate-200 hover:border-pink-400'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Stock Status & Quantity Selector */}
          <div className="flex items-center justify-between pt-2">
            <div>
              <span className="text-xs text-slate-500 font-medium block">Availability:</span>
              {product.stock > 0 ? (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  In Stock ({product.stock} units ready to ship)
                </span>
              ) : (
                <span className="text-xs font-bold text-rose-600 mt-0.5 block">
                  Out of Stock
                </span>
              )}
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Qty:</span>
              <div className="flex items-center border border-slate-200 rounded-xl bg-white overflow-hidden">
                <button
                  type="button"
                  disabled={quantity <= 1}
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-8 text-center text-xs font-bold text-slate-800 tabular-nums">
                  {quantity}
                </span>
                <button
                  type="button"
                  disabled={quantity >= product.stock}
                  onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                  className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Action Buttons: Add to Cart & Buy Now */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={handleAddToCart}
              disabled={product.stock <= 0}
              className="py-3 px-4 rounded-xl border-2 border-pink-600 text-pink-600 hover:bg-pink-50 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add to Cart</span>
            </button>

            <button
              type="button"
              onClick={handleBuyNowClick}
              disabled={product.stock <= 0}
              className="py-3 px-4 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-pink-200 transition-all disabled:opacity-50"
            >
              <Zap className="w-4 h-4" />
              <span>Buy Now</span>
            </button>
          </div>

          {/* Delivery & Pincode Checker */}
          <div className="p-4 rounded-2xl bg-white border border-pink-100 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
              <Truck className="w-4 h-4 text-pink-600" />
              <span>Delivery &amp; Payment Options</span>
            </div>
            
            <form onSubmit={checkPincode} className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={pincode}
                onChange={e => setPincode(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter 6-digit PIN"
                className="w-36 px-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 text-xs font-semibold text-pink-600 hover:text-pink-800 bg-pink-50 hover:bg-pink-100 rounded-xl"
              >
                Check
              </button>
            </form>

            {deliveryResult && (
              <p className="text-xs text-emerald-700 font-medium">
                ✓ {deliveryResult}
              </p>
            )}
          </div>

          {/* Garment Specifications & Fabric Details */}
          <div className="space-y-3 border-t border-slate-100 pt-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Garment Specifications
            </h3>
            
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-pink-50/30 border border-pink-100/60">
                <span className="text-slate-400 block text-[11px]">Fabric</span>
                <span className="font-semibold text-slate-800">{product.fabric}</span>
              </div>
              <div className="p-3 rounded-xl bg-pink-50/30 border border-pink-100/60">
                <span className="text-slate-400 block text-[11px]">Silhouette &amp; Fit</span>
                <span className="font-semibold text-slate-800">{product.fit}</span>
              </div>
              <div className="p-3 rounded-xl bg-pink-50/30 border border-pink-100/60">
                <span className="text-slate-400 block text-[11px]">Pattern / Work</span>
                <span className="font-semibold text-slate-800">{product.pattern}</span>
              </div>
              <div className="p-3 rounded-xl bg-pink-50/30 border border-pink-100/60">
                <span className="text-slate-400 block text-[11px]">Wash &amp; Care</span>
                <span className="font-semibold text-slate-800">{product.careInstructions}</span>
              </div>
            </div>

            <div className="pt-2 text-xs text-slate-600 leading-relaxed">
              <p>{product.description}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Verified Customer Ratings & Reviews */}
      <section className="bg-white rounded-3xl border border-pink-100 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <h2 className="text-lg sm:text-xl font-bold font-serif text-slate-900">
              Customer Ratings &amp; Reviews
            </h2>
            <p className="text-xs text-slate-500">Real feedback from verified purchasers</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-3xl font-extrabold text-slate-900 tabular-nums">
              {product.rating.toFixed(1)}
            </div>
            <div>
              <div className="flex items-center gap-0.5 text-amber-400">
                {[1, 2, 3, 4, 5].map(s => (
                  <Star key={s} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <div className="text-xs text-slate-500">{product.reviewCount} customer reviews</div>
            </div>
          </div>
        </div>

        {/* Reviews List */}
        <div className="space-y-4 divide-y divide-slate-100">
          {product.reviews.map(rev => (
            <div key={rev.id} className="pt-4 first:pt-0 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">{rev.userName}</span>
                  {rev.userCity && (
                    <span className="text-slate-400">· {rev.userCity}</span>
                  )}
                  {rev.verifiedPurchase && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Verified Buyer
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400">{rev.date}</span>
              </div>

              <div className="flex items-center gap-1">
                {[...Array(rev.rating)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-emerald-600 text-emerald-600" />
                ))}
                <span className="font-semibold text-slate-800 ml-1.5">{rev.title}</span>
              </div>

              <p className="text-slate-600 leading-relaxed">{rev.comment}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Similar Products Carousel */}
      {similarProducts.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg sm:text-xl font-bold font-serif text-slate-900">
              Similar {product.category} You May Like
            </h2>
            <button
              onClick={() => onNavigate('shop', { category: product.category })}
              className="text-xs font-semibold text-pink-600 hover:text-pink-700"
            >
              See More {product.category}
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
            {similarProducts.map(sim => (
              <ProductCard
                key={sim.id}
                product={sim}
                onSelect={onSelectProduct}
              />
            ))}
          </div>
        </section>
      )}

      {/* Size Chart Modal */}
      <SizeChartModal
        isOpen={sizeChartOpen}
        onClose={() => setSizeChartOpen(false)}
        category={product.category}
      />
    </div>
  );
}
