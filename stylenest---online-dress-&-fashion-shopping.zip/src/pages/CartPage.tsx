import React, { useState } from 'react';
import { 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  ShieldCheck, 
  Tag, 
  Check, 
  Truck,
  RotateCcw
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

interface CartPageProps {
  onNavigate: (tab: string, extra?: any) => void;
  onProceedToCheckout: () => void;
}

export function CartPage({ onNavigate, onProceedToCheckout }: CartPageProps) {
  const { 
    items, 
    updateQuantity, 
    removeFromCart, 
    totalItems, 
    subtotal, 
    originalTotal, 
    totalSavings, 
    deliveryCharge, 
    couponDiscount, 
    appliedCoupon, 
    applyCoupon, 
    removeCoupon, 
    finalTotal 
  } = useCart();

  const { isAuthenticated, openAuthModal } = useAuth();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = applyCoupon(couponInput);
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponError(null);
      setCouponInput('');
    }
  };

  const handleCheckoutClick = () => {
    if (!isAuthenticated) {
      openAuthModal();
      return;
    }
    onProceedToCheckout();
  };

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center space-y-6">
        <div className="w-20 h-20 bg-pink-50 rounded-full flex items-center justify-center mx-auto text-pink-600">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold font-serif text-slate-900">Your Shopping Bag is Empty</h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
            Discover thousands of stunning festive kurtis, sarees, and dresses at wholesale rates.
          </p>
        </div>
        <button
          onClick={() => onNavigate('shop')}
          className="px-6 py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md hover:from-pink-700 hover:to-purple-700 transition-all"
        >
          Explore Dresses Now
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-pink-100">
        <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900">
          Shopping Bag ({totalItems} {totalItems === 1 ? 'item' : 'items'})
        </h1>
        <button
          onClick={() => onNavigate('shop')}
          className="text-xs font-semibold text-pink-600 hover:text-pink-700"
        >
          + Add More Items
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          {items.map(item => (
            <div
              key={item.id}
              className="bg-white p-4 sm:p-5 rounded-2xl border border-pink-100/80 shadow-xs flex gap-4 sm:gap-6 items-start"
            >
              {/* Product Thumbnail */}
              <div className="w-20 sm:w-24 aspect-[4/5] rounded-xl overflow-hidden bg-pink-50 shrink-0 border border-slate-100">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Info & Quantity */}
              <div className="flex-1 flex flex-col justify-between self-stretch min-w-0">
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm sm:text-base font-semibold text-slate-900 line-clamp-1">
                      {item.name}
                    </h3>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                      title="Remove Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Size & Color Tags */}
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-600">
                    <span className="px-2 py-0.5 bg-slate-100 rounded-md font-medium text-slate-800">
                      Size: <strong>{item.size}</strong>
                    </span>
                    <span className="px-2 py-0.5 bg-slate-100 rounded-md font-medium text-slate-800">
                      Color: <strong>{item.color}</strong>
                    </span>
                  </div>
                </div>

                {/* Price & Quantity Controls */}
                <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-100">
                  <div className="flex items-baseline gap-2">
                    <span className="text-base sm:text-lg font-bold text-slate-900 tabular-nums">
                      ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                    {item.originalPrice > item.price && (
                      <span className="text-xs text-slate-400 line-through tabular-nums">
                        ₹{(item.originalPrice * item.quantity).toLocaleString('en-IN')}
                      </span>
                    )}
                  </div>

                  {/* Quantity Stepper with Stock Limit */}
                  <div className="flex items-center border border-slate-200 rounded-xl bg-white overflow-hidden">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-1.5 sm:p-2 text-slate-600 hover:bg-slate-100 transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 text-center text-xs font-bold text-slate-800 tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      disabled={item.quantity >= item.maxStock}
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-1.5 sm:p-2 text-slate-600 hover:bg-slate-100 transition-colors disabled:opacity-30"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Delivery & Trust banner */}
          <div className="p-4 rounded-2xl bg-pink-50/60 border border-pink-100/60 flex items-center justify-between text-xs text-slate-700">
            <span className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-pink-600" />
              {subtotal >= 499 ? (
                <strong className="text-emerald-700">Congratulations! You unlocked Free Delivery.</strong>
              ) : (
                <span>Add ₹{499 - subtotal} more for Free Delivery!</span>
              )}
            </span>
            <span className="flex items-center gap-1.5 text-slate-500 hidden sm:flex">
              <RotateCcw className="w-3.5 h-3.5" /> 7-Day Free Exchange
            </span>
          </div>
        </div>

        {/* Right: Price Breakdown & Checkout */}
        <div className="lg:col-span-4 space-y-5 sticky top-24">
          {/* Coupon Code Input */}
          <div className="bg-white p-5 rounded-2xl border border-pink-100/80 shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
              <Tag className="w-3.5 h-3.5 text-pink-600" />
              <span>Apply Coupons</span>
            </div>

            {appliedCoupon ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-emerald-800 font-mono">{appliedCoupon}</span>
                  <p className="text-[11px] text-emerald-700">Coupon applied! Saved ₹{couponDiscount}</p>
                </div>
                <button
                  onClick={removeCoupon}
                  className="text-xs text-rose-600 hover:underline font-semibold"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  value={couponInput}
                  onChange={e => setCouponInput(e.target.value)}
                  placeholder="Enter 'NEST10'"
                  className="flex-1 px-3 py-2 text-xs uppercase rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 font-mono"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  Apply
                </button>
              </form>
            )}

            {couponError && (
              <p className="text-[11px] text-rose-600">{couponError}</p>
            )}

            <p className="text-[11px] text-slate-400">
              Tip: Use code <strong className="text-pink-600 font-mono">NEST10</strong> for extra 10% discount.
            </p>
          </div>

          {/* Price Summary */}
          <div className="bg-white p-5 rounded-2xl border border-pink-100/80 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 uppercase tracking-wider text-xs">
              Price Details ({totalItems} Items)
            </h3>

            <div className="space-y-2.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Total M.R.P.</span>
                <span className="tabular-nums">₹{originalTotal.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex justify-between text-emerald-600">
                <span>Product Discount</span>
                <span className="tabular-nums">- ₹{totalSavings.toLocaleString('en-IN')}</span>
              </div>

              {couponDiscount > 0 && (
                <div className="flex justify-between text-purple-600">
                  <span>Coupon Discount ({appliedCoupon})</span>
                  <span className="tabular-nums">- ₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span className="tabular-nums font-medium">
                  {deliveryCharge === 0 ? (
                    <strong className="text-emerald-600 uppercase text-[11px]">FREE</strong>
                  ) : (
                    `₹${deliveryCharge}`
                  )}
                </span>
              </div>

              <div className="border-t border-slate-100 pt-3 flex justify-between text-sm sm:text-base font-bold text-slate-900">
                <span>Final Payable Amount</span>
                <span className="text-pink-600 tabular-nums">₹{finalTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Savings banner */}
            <div className="p-2.5 bg-emerald-50 rounded-xl text-[11px] text-emerald-800 text-center font-medium">
              🎉 You will save ₹{(totalSavings + couponDiscount).toLocaleString('en-IN')} on this order!
            </div>

            {/* Checkout CTA */}
            <button
              onClick={handleCheckoutClick}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-bold text-sm rounded-xl shadow-md shadow-pink-200 transition-all flex items-center justify-center gap-2"
            >
              <span>{isAuthenticated ? 'Proceed to Checkout' : 'Login & Place Order'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Safe payment badge */}
            <div className="pt-1 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Safe &amp; Secure Checkout · Cash on Delivery</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
