import React, { useState, useEffect } from 'react';
import { 
  Filter, 
  X, 
  SlidersHorizontal, 
  Star, 
  Search, 
  RotateCcw,
  ShoppingBag,
  ChevronDown
} from 'lucide-react';
import { Product, ProductCategory, ProductSize } from '../types';
import { ProductCard } from '../components/ProductCard';
import { fetchProducts } from '../services/api';

interface ShopPageProps {
  initialCategory?: string;
  initialSearch?: string;
  onSelectProduct: (product: Product) => void;
  onNavigate: (tab: string, extra?: any) => void;
}

export function ShopPage({ 
  initialCategory = 'All', 
  initialSearch = '', 
  onSelectProduct,
  onNavigate 
}: ShopPageProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter States
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [priceRange, setPriceRange] = useState<string>('all');
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [selectedColor, setSelectedColor] = useState<string>('All');
  const [minRating, setMinRating] = useState<number | undefined>(undefined);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>('popular');

  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Categories list
  const categories: (ProductCategory | 'All')[] = [
    'All',
    'Kurtis',
    'Sarees',
    'Tops',
    'Dresses',
    'Jeans',
    'Leggings',
    'Nightwear',
    'Traditional Wear'
  ];

  const sizes: (ProductSize | 'All')[] = ['All', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];

  const colors = [
    { name: 'All', hex: '' },
    { name: 'Pink', hex: '#f472b6' },
    { name: 'Lavender', hex: '#c084fc' },
    { name: 'Lilac', hex: '#d8b4fe' },
    { name: 'White', hex: '#ffffff' },
    { name: 'Blue', hex: '#38bdf8' },
    { name: 'Black', hex: '#0f172a' },
    { name: 'Rose', hex: '#fb7185' }
  ];

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    setSearchQuery(initialSearch);
  }, [initialSearch]);

  const loadProducts = async () => {
    setLoading(true);
    try {
      let minPrice: number | undefined;
      let maxPrice: number | undefined;

      if (priceRange === 'under-499') {
        maxPrice = 499;
      } else if (priceRange === '500-999') {
        minPrice = 500;
        maxPrice = 999;
      } else if (priceRange === '1000-1999') {
        minPrice = 1000;
        maxPrice = 1999;
      } else if (priceRange === '2000-plus') {
        minPrice = 2000;
      }

      const res = await fetchProducts({
        search: searchQuery,
        category: selectedCategory,
        minPrice,
        maxPrice,
        size: selectedSize,
        color: selectedColor === 'All' ? undefined : selectedColor,
        rating: minRating,
        inStock: inStockOnly,
        sort: sortBy
      });

      setProducts(res.products);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, [searchQuery, selectedCategory, priceRange, selectedSize, selectedColor, minRating, inStockOnly, sortBy]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setPriceRange('all');
    setSelectedSize('All');
    setSelectedColor('All');
    setMinRating(undefined);
    setInStockOnly(false);
    setSortBy('popular');
  };

  const hasActiveFilters = 
    selectedCategory !== 'All' || 
    priceRange !== 'all' || 
    selectedSize !== 'All' || 
    selectedColor !== 'All' || 
    minRating !== undefined || 
    inStockOnly || 
    searchQuery.trim() !== '';

  return (
    <div className="space-y-6">
      {/* 1. Shop Top Header & Sort Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-pink-100 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900">
            {selectedCategory === 'All' ? 'All Women’s Dresses & Ethnic Wear' : `${selectedCategory} Collection`}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Showing <strong className="text-slate-800 tabular-nums">{products.length}</strong> products
            {searchQuery && <span> matching "<strong>{searchQuery}</strong>"</span>}
          </p>
        </div>

        {/* Controls: Filter trigger for mobile + Sorting */}
        <div className="flex items-center gap-3 self-end sm:self-auto w-full md:w-auto justify-between sm:justify-end">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="md:hidden px-3.5 py-2 bg-pink-50 text-pink-700 hover:bg-pink-100 rounded-xl text-xs font-semibold flex items-center gap-2 border border-pink-200"
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filters {hasActiveFilters && '•'}</span>
          </button>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 hidden sm:inline">Sort by:</span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-100 cursor-pointer"
            >
              <option value="popular">Popularity & Rating</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="newest">Newest Arrivals</option>
              <option value="discount">Highest Discount</option>
            </select>
          </div>
        </div>
      </div>

      {/* 2. Main Layout (Sidebar Filter Desktop + Product Grid) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
        {/* Desktop Filter Sidebar */}
        <div className="hidden md:block bg-white p-5 rounded-2xl border border-pink-100 shadow-xs space-y-6 sticky top-24">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
              <SlidersHorizontal className="w-4 h-4 text-pink-600" />
              <span>Filters</span>
            </div>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-xs text-pink-600 hover:text-pink-800 font-semibold flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Reset All
              </button>
            )}
          </div>

          {/* Search inside filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Search by Keyword
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Kurti, saree, pink..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Categories
            </label>
            <div className="space-y-1 text-xs">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                    selectedCategory === cat
                      ? 'bg-pink-50 text-pink-700 font-bold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span>{cat}</span>
                  {selectedCategory === cat && <span className="text-pink-600">✓</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Price Range
            </label>
            <div className="space-y-1.5 text-xs text-slate-600">
              {[
                { id: 'all', label: 'All Prices' },
                { id: 'under-499', label: 'Under ₹499' },
                { id: '500-999', label: '₹500 to ₹999' },
                { id: '1000-1999', label: '₹1,000 to ₹1,999' },
                { id: '2000-plus', label: '₹2,000 & above' },
              ].map(opt => (
                <label key={opt.id} className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="radio"
                    name="price"
                    checked={priceRange === opt.id}
                    onChange={() => setPriceRange(opt.id)}
                    className="accent-pink-600"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Size Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Available Sizes
            </label>
            <div className="flex flex-wrap gap-1.5">
              {sizes.map(size => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                    selectedSize === size
                      ? 'bg-pink-600 text-white border-pink-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-pink-300'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Color Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Colours
            </label>
            <div className="flex flex-wrap gap-1.5">
              {colors.map(col => (
                <button
                  key={col.name}
                  onClick={() => setSelectedColor(col.name)}
                  className={`px-2.5 py-1 text-xs rounded-lg border flex items-center gap-1.5 transition-all ${
                    selectedColor === col.name
                      ? 'border-pink-600 bg-pink-50 text-pink-700 font-semibold'
                      : 'border-slate-200 text-slate-700 hover:border-pink-300'
                  }`}
                >
                  {col.hex && (
                    <span 
                      className="w-3 h-3 rounded-full border border-slate-300 inline-block"
                      style={{ backgroundColor: col.hex }}
                    />
                  )}
                  <span>{col.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Rating Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Minimum Rating
            </label>
            <div className="space-y-1 text-xs">
              {[4, 3].map(rating => (
                <button
                  key={rating}
                  onClick={() => setMinRating(minRating === rating ? undefined : rating)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition-colors ${
                    minRating === rating ? 'bg-pink-50 text-pink-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span className="flex items-center gap-1">
                    {rating}★ &amp; above
                  </span>
                  {minRating === rating && <span className="text-pink-600">✓</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Availability Filter */}
          <div className="pt-2 border-t border-slate-100">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={e => setInStockOnly(e.target.checked)}
                className="w-4 h-4 rounded text-pink-600 focus:ring-pink-500 accent-pink-600"
              />
              <span>In Stock Only</span>
            </label>
          </div>
        </div>

        {/* Product Grid Area */}
        <div className="md:col-span-3">
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="animate-pulse bg-white rounded-2xl p-3 border border-pink-100">
                  <div className="aspect-[4/5] bg-pink-100/50 rounded-xl mb-3" />
                  <div className="h-4 bg-pink-100/60 rounded w-2/3 mb-2" />
                  <div className="h-3 bg-pink-100/40 rounded w-full mb-3" />
                  <div className="h-5 bg-pink-100/50 rounded w-1/3" />
                </div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 sm:gap-6">
              {products.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={onSelectProduct}
                />
              ))}
            </div>
          ) : (
            /* Clear Empty State */
            <div className="bg-white rounded-2xl border border-pink-100 p-8 sm:p-12 text-center space-y-4">
              <div className="w-16 h-16 bg-pink-50 text-pink-600 rounded-full flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8 opacity-70" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  No Dresses Matched Your Search
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
                  We couldn't find any products matching your selected filters or keywords. Try clearing filters or searching for terms like "Kurti", "Saree", or "Dress".
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
                >
                  Clear All Filters
                </button>
                <button
                  onClick={() => setSelectedCategory('Kurtis')}
                  className="px-3 py-2 bg-pink-50 hover:bg-pink-100 text-pink-700 text-xs font-medium rounded-xl transition-colors"
                >
                  Browse Kurtis
                </button>
                <button
                  onClick={() => setSelectedCategory('Sarees')}
                  className="px-3 py-2 bg-pink-50 hover:bg-pink-100 text-pink-700 text-xs font-medium rounded-xl transition-colors"
                >
                  Browse Sarees
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Bottom-Sheet Filter Modal */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/60 backdrop-blur-sm sm:hidden animate-in fade-in">
          <div className="bg-white rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">Filter Dresses</h3>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Category */}
            <div>
              <span className="block text-xs font-bold text-slate-700 uppercase mb-2">Category</span>
              <div className="flex flex-wrap gap-1.5">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${
                      selectedCategory === cat
                        ? 'bg-pink-600 text-white border-pink-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <span className="block text-xs font-bold text-slate-700 uppercase mb-2">Price</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { id: 'all', label: 'All' },
                  { id: 'under-499', label: 'Under ₹499' },
                  { id: '500-999', label: '₹500 - ₹999' },
                  { id: '1000-1999', label: '₹1,000 - ₹1,999' },
                  { id: '2000-plus', label: '₹2,000+' },
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => setPriceRange(opt.id)}
                    className={`py-2 px-3 text-center rounded-xl border text-xs font-medium ${
                      priceRange === opt.id
                        ? 'bg-pink-50 text-pink-700 border-pink-500 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div>
              <span className="block text-xs font-bold text-slate-700 uppercase mb-2">Size</span>
              <div className="flex flex-wrap gap-1.5">
                {sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${
                      selectedSize === size
                        ? 'bg-pink-600 text-white border-pink-600'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center gap-3">
              <button
                onClick={resetFilters}
                className="flex-1 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl"
              >
                Reset
              </button>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-pink-600 rounded-xl shadow-md"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
