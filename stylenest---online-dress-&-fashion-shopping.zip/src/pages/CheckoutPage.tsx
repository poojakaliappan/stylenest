import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Banknote, 
  CreditCard, 
  MapPin, 
  User as UserIcon, 
  Phone, 
  CheckCircle2, 
  Truck,
  ArrowLeft,
  AlertCircle
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { createOrder } from '../services/api';
import { Order, UserAddress } from '../types';

interface CheckoutPageProps {
  onBackToCart: () => void;
  onOrderSuccess: (order: Order) => void;
}

export function CheckoutPage({ onBackToCart, onOrderSuccess }: CheckoutPageProps) {
  const { items, subtotal, deliveryCharge, couponDiscount, finalTotal, clearCart } = useCart();
  const { user, updateProfile } = useAuth();
  const { showToast } = useToast();

  const [address, setAddress] = useState<UserAddress>({
    fullName: user?.address?.fullName || user?.name || '',
    phone: user?.address?.phone || user?.phone || '',
    street: user?.address?.street || '',
    city: user?.address?.city || '',
    state: user?.address?.state || 'Karnataka',
    pincode: user?.address?.pincode || ''
  });

  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'Online (UPI/Cards)'>('COD');
  const [saveAsDefault, setSaveAsDefault] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const indianStates = [
    'Andhra Pradesh', 'Assam', 'Bihar', 'Delhi NCR', 'Gujarat', 'Haryana', 
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Odisha', 
    'Punjab', 'Rajasthan', 'Tamil Nadu', 'Telangana', 'Uttar Pradesh', 'West Bengal'
  ];

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!address.fullName.trim() || !address.phone.trim() || !address.street.trim() || !address.city.trim() || !address.pincode.trim()) {
      setError('Please provide complete shipping address details.');
      showToast('Please complete all address fields', 'error');
      return;
    }

    if (address.phone.replace(/\D/g, '').length < 10) {
      setError('Please enter a valid 10-digit mobile number for courier SMS updates.');
      showToast('Invalid phone number', 'error');
      return;
    }

    if (address.pincode.replace(/\D/g, '').length !== 6) {
      setError('Please enter a valid 6-digit postal PIN code.');
      showToast('Invalid 6-digit PIN code', 'error');
      return;
    }

    setSubmitting(true);

    try {
      if (saveAsDefault) {
        updateProfile({ address, phone: address.phone, name: address.fullName });
      }

      const orderPayload = {
        userId: user?.id || 'usr-guest',
        items: items.map(item => ({
          productId: item.productId,
          name: item.name,
          size: item.size,
          color: item.color,
          price: item.price,
          quantity: item.quantity
        })),
        shippingAddress: address,
        paymentMethod
      };

      const res = await createOrder(orderPayload);
      clearCart();
      showToast('🎉 Order placed successfully!', 'success');
      onOrderSuccess(res.order);
    } catch (err: any) {
      setError(err.message || 'Failed to submit order');
      showToast(err.message || 'Error creating order', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-pink-100">
        <button
          onClick={onBackToCart}
          className="text-xs font-semibold text-slate-600 hover:text-pink-600 flex items-center gap-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Bag</span>
        </button>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>100% Secure Checkout</span>
        </div>
      </div>

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Delivery Address & Payment Method */}
        <div className="lg:col-span-7 space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Delivery Address Card */}
          <div className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xs space-y-4">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 border-b border-slate-100 pb-3">
              <MapPin className="w-4 h-4 text-pink-600" />
              <span>1. Delivery Address</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Full Name *</label>
                <div className="relative">
                  <UserIcon className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={address.fullName}
                    onChange={e => setAddress({ ...address, fullName: e.target.value })}
                    placeholder="e.g. Pooja Kaliappan"
                    className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Mobile Phone (10 digits) *</label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={address.phone}
                    onChange={e => setAddress({ ...address, phone: e.target.value.replace(/\D/g, '') })}
                    placeholder="9876543210"
                    className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-medium text-slate-700 mb-1">Flat / House No., Apartment, Street Address *</label>
                <input
                  type="text"
                  required
                  value={address.street}
                  onChange={e => setAddress({ ...address, street: e.target.value })}
                  placeholder="e.g. Flat 402, Lotus Orchid Apartments, MG Road"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">City / Town *</label>
                <input
                  type="text"
                  required
                  value={address.city}
                  onChange={e => setAddress({ ...address, city: e.target.value })}
                  placeholder="e.g. Bengaluru"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">State *</label>
                <select
                  value={address.state}
                  onChange={e => setAddress({ ...address, state: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500 bg-white"
                >
                  {indianStates.map(st => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">6-Digit PIN Code *</label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={address.pincode}
                  onChange={e => setAddress({ ...address, pincode: e.target.value.replace(/\D/g, '') })}
                  placeholder="560001"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
                />
              </div>

              <div className="sm:col-span-2 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-slate-600">
                  <input
                    type="checkbox"
                    checked={saveAsDefault}
                    onChange={e => setSaveAsDefault(e.target.checked)}
                    className="accent-pink-600 rounded"
                  />
                  <span>Save this address for fast 1-click future orders</span>
                </label>
              </div>
            </div>
          </div>

          {/* Payment Method Card */}
          <div className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xs space-y-4">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 border-b border-slate-100 pb-3">
              <Banknote className="w-4 h-4 text-purple-600" />
              <span>2. Payment Option</span>
            </div>

            <div className="space-y-3 text-xs">
              {/* Cash On Delivery */}
              <label className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                paymentMethod === 'COD'
                  ? 'border-pink-600 bg-pink-50/50 ring-2 ring-pink-100'
                  : 'border-slate-200 hover:border-pink-200'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'COD'}
                  onChange={() => setPaymentMethod('COD')}
                  className="mt-0.5 accent-pink-600"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span className="flex items-center gap-2">
                      <Banknote className="w-4 h-4 text-emerald-600" />
                      Cash on Delivery (COD)
                    </span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded font-bold uppercase">
                      Recommended
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Pay cash to the delivery agent when your parcel arrives at your doorstep. Zero advance payment needed.
                  </p>
                </div>
              </label>

              {/* Online Payment (UPI / Cards simulation) */}
              <label className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                paymentMethod === 'Online (UPI/Cards)'
                  ? 'border-pink-600 bg-pink-50/50 ring-2 ring-pink-100'
                  : 'border-slate-200 hover:border-pink-200'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'Online (UPI/Cards)'}
                  onChange={() => setPaymentMethod('Online (UPI/Cards)')}
                  className="mt-0.5 accent-pink-600"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-purple-600" />
                      Online Payment (UPI, GPay, PhonePe, Cards)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Instant test mode verification. When live Razorpay/PayU gateway keys are added to the backend, live payment is processed.
                  </p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Order Summary & Place Order */}
        <div className="lg:col-span-5 space-y-5 sticky top-24">
          <div className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 border-b border-slate-100 pb-3 text-sm uppercase tracking-wider">
              Order Summary ({items.length} items)
            </h3>

            {/* Items mini list */}
            <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 pr-1 space-y-2">
              {items.map(item => (
                <div key={item.id} className="pt-2 first:pt-0 flex items-center gap-3 text-xs">
                  <img src={item.image} alt={item.name} className="w-12 h-14 object-cover rounded-lg bg-pink-50 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800 truncate">{item.name}</p>
                    <p className="text-[11px] text-slate-500">Size: {item.size} · Color: {item.color} · Qty: {item.quantity}</p>
                  </div>
                  <span className="font-bold text-slate-900 tabular-nums">
                    ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>

            {/* Calculations */}
            <div className="border-t border-slate-100 pt-3 space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="tabular-nums">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {couponDiscount > 0 && (
                <div className="flex justify-between text-purple-600 font-medium">
                  <span>Coupon Savings</span>
                  <span className="tabular-nums">- ₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Delivery Charge</span>
                <span className="tabular-nums font-semibold text-emerald-600">
                  {deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}
                </span>
              </div>

              <div className="border-t border-slate-100 pt-2 flex justify-between text-base font-extrabold text-slate-900">
                <span>Total Amount</span>
                <span className="text-pink-600 tabular-nums">₹{finalTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white font-bold text-sm rounded-xl shadow-md shadow-pink-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {submitting ? (
                <span>Confirming Order...</span>
              ) : (
                <span>Place Order (₹{finalTotal.toLocaleString('en-IN')})</span>
              )}
            </button>

            <div className="text-[11px] text-slate-500 text-center flex items-center justify-center gap-1">
              <Truck className="w-3.5 h-3.5 text-pink-600" />
              <span>Estimated Delivery: 3 to 4 business days</span>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
