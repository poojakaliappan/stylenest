import React, { useState } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  MapPin, 
  Package, 
  Heart, 
  Save, 
  LogOut, 
  CheckCircle2, 
  ShieldCheck 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { UserAddress } from '../types';

interface ProfilePageProps {
  onNavigate: (tab: string, extra?: any) => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, updateProfile, logout } = useAuth();
  const { showToast } = useToast();

  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [address, setAddress] = useState<UserAddress>({
    fullName: user?.address?.fullName || user?.name || '',
    phone: user?.address?.phone || user?.phone || '',
    street: user?.address?.street || '',
    city: user?.address?.city || '',
    state: user?.address?.state || 'Karnataka',
    pincode: user?.address?.pincode || ''
  });

  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfile({
        name,
        phone,
        address
      });
      showToast('Profile and delivery details saved successfully!', 'success');
    } catch {
      showToast('Failed to update profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-pink-100">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900">
            My Customer Account
          </h1>
          <p className="text-xs text-slate-500">Manage your profile, shipping addresses, and preferences</p>
        </div>
        <button
          onClick={logout}
          className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Log Out</span>
        </button>
      </div>

      {/* Account Quick Dashboard */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="bg-white p-4 rounded-2xl border border-pink-100 shadow-xs flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-pink-100 text-pink-700 font-bold text-base flex items-center justify-center uppercase">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div>
            <span className="font-bold text-slate-900 text-sm block truncate">{user?.name}</span>
            <span className="text-slate-500 text-[11px] block truncate">{user?.email}</span>
          </div>
        </div>

        <button
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-2xl border border-pink-100 shadow-xs flex items-center justify-between hover:bg-pink-50/50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-slate-900 block text-sm">My Orders</span>
              <span className="text-slate-500 text-[11px]">Track active shipments</span>
            </div>
          </div>
          <span className="text-pink-600 font-bold">→</span>
        </button>

        <button
          onClick={() => onNavigate('wishlist')}
          className="bg-white p-4 rounded-2xl border border-pink-100 shadow-xs flex items-center justify-between hover:bg-pink-50/50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-slate-900 block text-sm">Saved Wishlist</span>
              <span className="text-slate-500 text-[11px]">View saved dresses</span>
            </div>
          </div>
          <span className="text-pink-600 font-bold">→</span>
        </button>
      </div>

      {/* Edit Form */}
      <form onSubmit={handleSave} className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xs space-y-6">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
          <UserIcon className="w-4 h-4 text-pink-600" />
          <span>Personal &amp; Default Delivery Information</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Email Address (Read-only)</label>
            <input
              type="email"
              disabled
              value={user?.email || ''}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Mobile Phone (10 digits)</label>
            <input
              type="tel"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="9876543210"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Recipient Name</label>
            <input
              type="text"
              value={address.fullName}
              onChange={e => setAddress({ ...address, fullName: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block font-medium text-slate-700 mb-1">Delivery Street Address</label>
            <input
              type="text"
              value={address.street}
              onChange={e => setAddress({ ...address, street: e.target.value })}
              placeholder="House/Flat number, apartment, street name"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">City</label>
            <input
              type="text"
              value={address.city}
              onChange={e => setAddress({ ...address, city: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">PIN Code (6 digits)</label>
            <input
              type="text"
              maxLength={6}
              value={address.pincode}
              onChange={e => setAddress({ ...address, pincode: e.target.value.replace(/\D/g, '') })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-pink-500"
            />
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Encrypted customer data storage</span>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saving ? 'Saving...' : 'Save Profile'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
