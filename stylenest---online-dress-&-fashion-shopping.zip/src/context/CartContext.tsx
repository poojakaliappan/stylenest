import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product, ProductSize } from '../types';
import { useToast } from './ToastContext';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, size: ProductSize, color: string, quantity?: number) => boolean;
  updateQuantity: (itemId: string, quantity: number) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  originalTotal: number;
  totalSavings: number;
  deliveryCharge: number;
  couponDiscount: number;
  appliedCoupon: string | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  finalTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);
const CART_STORAGE_KEY = 'stylenest_cart_v1';

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('NEST10');
  const { showToast } = useToast();

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) {
        setItems(JSON.parse(saved));
      } else {
        // Pre-populate with 1 realistic starter dress for immediate gratification
        const initialItem: CartItem = {
          id: 'sn-prod-001_M_Blush Rose',
          productId: 'sn-prod-001',
          name: 'Embroidered Anarkali Kurti with Dupatta',
          image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80',
          category: 'Kurtis',
          size: 'M',
          color: 'Blush Rose',
          price: 849,
          originalPrice: 1999,
          quantity: 1,
          maxStock: 18
        };
        setItems([initialItem]);
        localStorage.setItem(CART_STORAGE_KEY, JSON.stringify([initialItem]));
      }
    } catch {
      // ignore
    }
  }, []);

  const saveItems = (newItems: CartItem[]) => {
    setItems(newItems);
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(newItems));
    } catch {}
  };

  const addToCart = (product: Product, size: ProductSize, color: string, quantity = 1): boolean => {
    if (!size || !color) {
      showToast('Please select your preferred size and colour first', 'error');
      return false;
    }

    if (product.stock <= 0) {
      showToast(`Sorry, "${product.name}" is currently out of stock.`, 'error');
      return false;
    }

    const itemId = `${product.id}_${size}_${color}`;
    const existingIndex = items.findIndex(i => i.id === itemId);

    let updated = [...items];
    if (existingIndex >= 0) {
      const existing = updated[existingIndex];
      const newQty = existing.quantity + quantity;
      if (newQty > product.stock) {
        showToast(`Only ${product.stock} items available in stock. Cannot add more.`, 'error');
        return false;
      }
      updated[existingIndex] = { ...existing, quantity: newQty };
    } else {
      if (quantity > product.stock) {
        showToast(`Only ${product.stock} items available in stock.`, 'error');
        return false;
      }
      updated.push({
        id: itemId,
        productId: product.id,
        name: product.name,
        image: product.images[0],
        category: product.category,
        size,
        color,
        price: product.sellingPrice,
        originalPrice: product.originalPrice,
        quantity,
        maxStock: product.stock
      });
    }

    saveItems(updated);
    showToast(`Added "${product.name}" (${size}, ${color}) to cart!`, 'success');
    return true;
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(itemId);
      return;
    }

    const updated = items.map(item => {
      if (item.id === itemId) {
        if (newQuantity > item.maxStock) {
          showToast(`Maximum available stock reached (${item.maxStock} units).`, 'error');
          return { ...item, quantity: item.maxStock };
        }
        return { ...item, quantity: newQuantity };
      }
      return item;
    });

    saveItems(updated);
  };

  const removeFromCart = (itemId: string) => {
    const item = items.find(i => i.id === itemId);
    const updated = items.filter(i => i.id !== itemId);
    saveItems(updated);
    if (item) {
      showToast(`Removed "${item.name}" from your bag.`, 'info');
    }
  };

  const clearCart = () => {
    saveItems([]);
  };

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const originalTotal = items.reduce((sum, item) => sum + item.originalPrice * item.quantity, 0);
  const totalSavings = originalTotal - subtotal;
  
  // Free delivery threshold: ₹499
  const deliveryCharge = totalItems === 0 ? 0 : subtotal >= 499 ? 0 : 49;

  let couponDiscount = 0;
  if (appliedCoupon === 'NEST10') {
    couponDiscount = Math.round(subtotal * 0.1);
  } else if (appliedCoupon === 'STYLENEST50') {
    couponDiscount = Math.min(500, Math.round(subtotal * 0.15));
  }

  const finalTotal = Math.max(0, subtotal - couponDiscount + deliveryCharge);

  const applyCoupon = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'NEST10') {
      setAppliedCoupon('NEST10');
      showToast('Coupon NEST10 applied! Extra 10% off unlocked.', 'success');
      return { success: true, message: '10% discount applied!' };
    }
    if (clean === 'STYLENEST50') {
      setAppliedCoupon('STYLENEST50');
      showToast('Special festival coupon applied! 15% off up to ₹500.', 'success');
      return { success: true, message: '15% discount applied!' };
    }
    showToast('Invalid coupon code. Try "NEST10"', 'error');
    return { success: false, message: 'Invalid or expired coupon' };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    showToast('Coupon removed.', 'info');
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        totalItems,
        subtotal,
        originalTotal,
        totalSavings,
        deliveryCharge,
        couponDiscount,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        finalTotal
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
