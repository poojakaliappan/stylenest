import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserAddress } from '../types';
import { API_BASE } from '../services/api';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAuthModalOpen: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
  login: (email: string, password?: string) => Promise<void>;
  register: (name: string, email: string, password?: string, phone?: string) => Promise<void>;
  logout: () => void;
  updateProfile: (data: { name?: string; phone?: string; address?: UserAddress }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER_STORAGE_KEY = 'stylenest_user_session';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  useEffect(() => {
    // Load persisted customer session
    try {
      const savedUser = localStorage.getItem(DEMO_USER_STORAGE_KEY);
      if (savedUser) {
        setUser(JSON.parse(savedUser));
      } else {
        // Auto initialize default demo customer profile for seamless instant experience
        const defaultCustomer: User = {
          id: 'usr-demo-01',
          name: 'Pooja Kaliappan',
          email: 'poojakaliappan490@gmail.com',
          phone: '9876543210',
          address: {
            fullName: 'Pooja Kaliappan',
            phone: '9876543210',
            street: 'Flat 402, Lotus Orchid Apartments, MG Road',
            city: 'Bengaluru',
            state: 'Karnataka',
            pincode: '560001'
          },
          wishlist: ['sn-prod-001', 'sn-prod-003'],
          createdAt: new Date().toISOString()
        };
        setUser(defaultCustomer);
        localStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(defaultCustomer));
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, password = 'password123') => {
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      
      setUser(data.user);
      localStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(data.user));
      setIsAuthModalOpen(false);
    } catch (err: any) {
      throw new Error(err.message || 'Login failed');
    }
  };

  const register = async (name: string, email: string, password = 'password123', phone = '') => {
    try {
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, phone })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Registration failed');

      setUser(data.user);
      localStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(data.user));
      setIsAuthModalOpen(false);
    } catch (err: any) {
      throw new Error(err.message || 'Registration failed');
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(DEMO_USER_STORAGE_KEY);
  };

  const updateProfile = async (data: { name?: string; phone?: string; address?: UserAddress }) => {
    if (!user) return;
    try {
      const res = await fetch(`${API_BASE}/auth/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, ...data })
      });
      const resData = await res.json();
      const updatedUser = resData.user || { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(updatedUser));
    } catch {
      // Local fallback
      const updatedUser = {
        ...user,
        name: data.name ?? user.name,
        phone: data.phone ?? user.phone,
        address: data.address ?? user.address
      };
      setUser(updatedUser);
      localStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isAuthModalOpen,
        openAuthModal: () => setIsAuthModalOpen(true),
        closeAuthModal: () => setIsAuthModalOpen(false),
        login,
        register,
        logout,
        updateProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
