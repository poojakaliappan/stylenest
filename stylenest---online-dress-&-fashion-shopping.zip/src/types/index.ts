export type ProductCategory = 
  | 'Kurtis' 
  | 'Sarees' 
  | 'Tops' 
  | 'Dresses' 
  | 'Jeans' 
  | 'Leggings' 
  | 'Nightwear' 
  | 'Traditional Wear';

export type ProductSize = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface ProductReview {
  id: string;
  userName: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
  userCity?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: ProductCategory;
  brand: string;
  originalPrice: number;
  sellingPrice: number;
  discountPercent: number;
  images: string[];
  sizes: ProductSize[];
  colors: {
    name: string;
    hex: string;
  }[];
  fabric: string;
  fit: string;
  pattern: string;
  careInstructions: string;
  stock: number;
  rating: number;
  reviewCount: number;
  isNewArrival?: boolean;
  isTrending?: boolean;
  isBestSeller?: boolean;
  isSpecialOffer?: boolean;
  isPublished: boolean;
  description: string;
  reviews: ProductReview[];
  createdAt: string;
}

export interface CartItem {
  id: string; // unique item id composed of productId_size_color
  productId: string;
  name: string;
  image: string;
  category: string;
  size: ProductSize;
  color: string;
  price: number;
  originalPrice: number;
  quantity: number;
  maxStock: number;
}

export interface UserAddress {
  fullName: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  pincode: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  address?: UserAddress;
  wishlist: string[];
  createdAt: string;
}

export type OrderStatus = 'Placed' | 'Confirmed' | 'Shipped' | 'Delivered' | 'Cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  size: ProductSize;
  color: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  date: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  deliveryCharge: number;
  totalAmount: number;
  shippingAddress: UserAddress;
  paymentMethod: 'COD' | 'Online (UPI/Cards)';
  paymentStatus: 'Pending' | 'Paid';
  status: OrderStatus;
  estimatedDelivery: string;
  timeline: {
    status: OrderStatus;
    timestamp: string;
    description: string;
    completed: boolean;
  }[];
}

export interface BackendStatus {
  connected: boolean;
  database: 'mongodb' | 'memory-store';
  productCount: number;
  ordersCount: number;
  mongoUriConfigured: boolean;
  message: string;
}
