import React, { useState, useEffect } from 'react';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';

import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';
import { DatabaseStatusModal } from './components/DatabaseStatusModal';
import { AuthModal } from './components/AuthModal';

import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { OrdersPage } from './pages/OrdersPage';
import { WishlistPage } from './pages/WishlistPage';
import { ProfilePage } from './pages/ProfilePage';

import { Product, ProductSize, Order } from './types';
import { fetchCategories } from './services/api';

function MainApp() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  const [dbModalOpen, setDbModalOpen] = useState(false);
  const [categories, setCategories] = useState<{ name: string; slug: string }[]>([]);

  const { addToCart } = useCart();

  useEffect(() => {
    async function loadCats() {
      try {
        const data = await fetchCategories();
        setCategories(data.categories || []);
      } catch (err) {
        // Fallback categories
        setCategories([
          { name: 'Kurtis', slug: 'kurtis' },
          { name: 'Sarees', slug: 'sarees' },
          { name: 'Tops', slug: 'tops' },
          { name: 'Dresses', slug: 'dresses' },
          { name: 'Jeans', slug: 'jeans' },
          { name: 'Leggings', slug: 'leggings' },
          { name: 'Nightwear', slug: 'nightwear' },
          { name: 'Traditional Wear', slug: 'traditional-wear' }
        ]);
      }
    }
    loadCats();
  }, []);

  const handleNavigate = (tab: string, extra?: any) => {
    if (extra?.category) {
      setSelectedCategory(extra.category);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentTab('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setCurrentTab('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBuyNow = (product: Product, size: ProductSize, color: string, quantity: number) => {
    addToCart(product, size, color, quantity);
    setCurrentTab('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSuccess = (order: Order) => {
    setLastPlacedOrder(order);
    setCurrentTab('order-confirmation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf7fb] text-slate-800">
      {/* Global Header */}
      <Header
        currentTab={currentTab}
        onNavigate={handleNavigate}
        onSearch={handleSearch}
        onOpenDatabaseStatus={() => setDbModalOpen(true)}
        categories={categories}
      />

      {/* Main Page Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'home' && (
          <HomePage
            onSelectProduct={handleSelectProduct}
            onNavigate={handleNavigate}
            onOpenDatabaseStatus={() => setDbModalOpen(true)}
          />
        )}

        {currentTab === 'shop' && (
          <ShopPage
            initialCategory={selectedCategory}
            initialSearch={searchQuery}
            onSelectProduct={handleSelectProduct}
            onNavigate={handleNavigate}
          />
        )}

        {currentTab === 'product-detail' && selectedProduct && (
          <ProductDetailPage
            productId={selectedProduct.id}
            onSelectProduct={handleSelectProduct}
            onNavigate={handleNavigate}
            onBuyNow={handleBuyNow}
          />
        )}

        {currentTab === 'cart' && (
          <CartPage
            onNavigate={handleNavigate}
            onProceedToCheckout={() => handleNavigate('checkout')}
          />
        )}

        {currentTab === 'checkout' && (
          <CheckoutPage
            onBackToCart={() => handleNavigate('cart')}
            onOrderSuccess={handleOrderSuccess}
          />
        )}

        {currentTab === 'order-confirmation' && lastPlacedOrder && (
          <OrderConfirmationPage
            order={lastPlacedOrder}
            onNavigate={handleNavigate}
          />
        )}

        {currentTab === 'orders' && (
          <OrdersPage
            onNavigate={handleNavigate}
          />
        )}

        {currentTab === 'wishlist' && (
          <WishlistPage
            onSelectProduct={handleSelectProduct}
            onNavigate={handleNavigate}
          />
        )}

        {currentTab === 'profile' && (
          <ProfilePage
            onNavigate={handleNavigate}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenDatabaseStatus={() => setDbModalOpen(true)}
      />

      {/* Mobile Bottom Bar (Meesho/Flipkart Native Navigation) */}
      <MobileBottomNav
        currentTab={currentTab}
        onNavigate={handleNavigate}
      />

      {/* Database & MongoDB Atlas Status Modal */}
      <DatabaseStatusModal
        isOpen={dbModalOpen}
        onClose={() => setDbModalOpen(false)}
      />

      {/* Customer Login / Register Modal */}
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <CartProvider>
          <WishlistProvider>
            <MainApp />
          </WishlistProvider>
        </CartProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
